using namespace std;
#include<iostream>
#include<string>

typedef class Node
{
    public:
    int Eid;
    char Ename[20];
    char Eaddress[30];
    char Eproject[30];
    char Egender;
    float Esalary;
    int Eage;
    Node*Next;
    Node*Prev;

    Node(int,char*,char*,char*,char,float,int);
}NODE,*PNODE,**PPNODE;

Node::Node(int id, char*name,char*address,char*project,char gender,float salary,int age)
{
    int i=0;
    Eid=id;
    while(name[i]!='\0')
    {
        Ename[i]=name[i];
        i++;
    }
    Ename[i]='\0';
    i=0;
    while(address[i]!='\0')
    {
        Eaddress[i]=address[i];
        i++;
    }
    Eaddress[i]='\0';
    i=0;
    while(project[i]!='\0')
    {
        Eproject[i]=project[i];
        i++;
    }
    Eproject[i]='\0';
    if((gender=='m')||(gender=='f'))
    {
        gender=gender-32;
    }
    Egender=gender;
    Esalary=salary;
    Eage=age;
    Next=NULL;
    Prev=NULL;
}

class Employee
{
    private:
    PNODE Head;
    int cnt;

    public:
    Employee();
    void InsertFirst(int,char*,char*,char*,char,float,int);
    void InsertLast(int,char*,char*,char*,char,float,int);
    void InsertAtPos(int,char*,char*,char*,char,float,int,int);
    void DeleteAtPos(int);
    void DeleteLast();
    void DeleteFirst();
    void Display();
    int Count();

    
};

Employee::Employee()
{
    Head=NULL;
    cnt=0;
}
void Employee::InsertFirst(int id, char*name,char* address,char* project,char gender,float salary,int age)
{
    PNODE Newn=new NODE(id,name,address,project,gender,salary,age);

    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        Head->Prev=Newn;
        Newn->Next=Head;
        Head=Newn;
    }
    cnt++;
}
void Employee::DeleteFirst()
{
    if(Head==NULL)
    {
        return;
    }
    else
    {
        if(Head->Next==NULL)
        {
            delete(Head);
            Head=NULL;
        }  
        else
        {
            Head=Head->Next;
            delete(Head->Prev);
            Head->Prev=NULL;
        }    
    }
    cnt--;
}
void Employee::DeleteLast()
{
    if(Head==NULL)
    {
        return;
    }
    else
    {
        if(Head->Next==NULL)
        {
            delete(Head);
            Head=NULL;
        }  
        else
        {
            PNODE Temp=Head;
            while(Temp->Next!=NULL)
            {
                Temp=Temp->Next;
            }
            Temp->Prev->Next=NULL;
            delete(Temp);
        }
              
    }
    cnt--;
}

void Employee::InsertLast(int id, char*name,char* address,char* project,char gender,float salary,int age)
{
    PNODE Newn=new NODE(id,name,address,project,gender,salary,age);

    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        PNODE Temp=Head;

        while(Temp->Next!=NULL)
        {
            Temp=Temp->Next;
        }
        Newn->Prev=Temp;
        Temp->Next=Newn;
    }
    cnt++;
}

void Employee::Display()
{
    if(Head==NULL)
    {
        return;
    }
    PNODE Temp=Head;

    while(Temp!=NULL)
    {
        int i=0;

        cout<<"\n"<<"Eid"<<"->"<<Temp->Eid<<"\n";
        cout<<"Ename"<<"->";
        while(Temp->Ename[i]!='\0')
        {
            cout<<Temp->Ename[i];
            i++;
        }
        cout<<"\n";
        i=0;
        cout<<"Eaddress"<<"->";
        while(Temp->Eaddress[i]!='\0')
        {
            cout<<Temp->Eaddress[i];
            i++;
        }
        cout<<"\n";
        i=0;
        cout<<"Eproject"<<"->";
        while(Temp->Eproject[i]!='\0')
        {
            cout<<Temp->Eproject[i];
            i++;
        }
        cout<<"\n";
        cout<<"Egender"<<"->"<<Temp->Egender<<"\n"<<"Esalary"<<"->"<<Temp->Esalary<<"\n"<<"Eage"<<"->"<<Temp->Eage<<"\n";

        Temp=Temp->Next;
    }
}

int Employee:: Count()
{
    return cnt;
}

void Employee::InsertAtPos(int id, char*name,char* address,char* project,char gender,float salary,int age,int iPos)
{

    int iSize=Count();
    if((iPos<1)||(iPos>iSize+1))
    {
        return;
    }
    if(iPos==1)
    {
        InsertFirst(id,name,address,project,gender,salary,age);
        
    }
    if(iPos==(iSize+1))
    {
        InsertLast(id,name,address,project,gender,salary,age);
    }
    else
    {
        PNODE Newn=new NODE(id,name,address,project,gender,salary,age);
        PNODE Temp=Head;
        int i=1;
        for(i=1;i<iPos-1;i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next->Prev=Newn;
        Newn->Prev=Temp;
        Temp->Next=Newn;
        cnt++;
    }
    
}
void Employee::DeleteAtPos(int iPos)
{

    int iSize=Count();
    if((iPos<1)||(iPos>iSize))
    {
        return;
    }
    if(iPos==1)
    {
        DeleteFirst();
        
    }
    if(iPos==(iSize))
    {
        DeleteLast();
    }
    else
    {
        PNODE Temp=Head;
        int i=1;
        for(i=1;i<iPos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp->Next=Temp->Next->Next;
        delete(Temp->Next->Prev);
        Temp->Next->Prev=Temp;
        cnt--;
    }
    
}

int main()
{
    Employee obj;
    int iChoice=1,Eid=0;
    char Ename[20]={'\0'};
    char Eaddress[30]={'\0'};
    char Eproject[30]={'\0'};
    char Egender='\0';
    float Esalary=0.0;
    int Eage=0;

    int iCount=0;
    int iPos=0;
    while(iChoice!=0)
    {
        cout<<"\n---------------------------------------------------------------------------------------\n";
        cout<<"Enter:\n";
        cout<<"1.To Enter the information of the Employee at First Position.\n";
        cout<<"2.To Enter the information of the Employee at Last Position.\n";
        cout<<"3.To Enter the information of the Employee at selected Position.\n";
        cout<<"4.To Delete the information of the Employee at first Position.\n";
        cout<<"5.To Delete the information of the Employee at last Position.\n";
        cout<<"6.To Delete the information of the Employee at selected Position.\n";
        cout<<"7.To Display.\n";
        cout<<"8.To Count.\n";
        cout<<"0.Exit.\n";
        cout<<"---------------------------------------------------------------------------------------\n";
        cout<<"Enter Option\n";
        cin>>iChoice;
        cout<<"---------------------------------------------------------------------------------------\n";

        switch(iChoice)
        {
            case 1:
                cout<<"Enter Employee id\n";
                cin>>Eid;
                cin.ignore();
                cout<<"Enter Employee name\n";
                cin.getline(Ename,20);
                cout<<"Enter Employee Address\n";
                cin.getline(Eaddress,30);
                cout<<"Enter Employee Project\n";
                cin.getline(Eproject,30);
                cout<<"Enter Employee Gender.(M/F)\n";
                cin>>Egender;
                while((Egender!='m')&&(Egender!='M')&&(Egender!='f')&&(Egender!='F'))
                {
                    cout<<"Please Enter M for Male. OR F for Female.\n";
                    cin>>Egender;
                }
                cout<<"Enter Employee Salary\n";
                cin>>Esalary;
                cout<<"Enter Employee Age\n";
                cin>>Eage;

                obj.InsertFirst(Eid,Ename,Eaddress,Eproject,Egender,Esalary,Eage);
            break;
            case 2:
                cout<<"Enter Employee id\n";
                cin>>Eid;
                cin.ignore();
                cout<<"Enter Employee name\n";
                cin.getline(Ename,20);
                cout<<"Enter Employee Address\n";
                cin.getline(Eaddress,30);
                cout<<"Enter Employee Project\n";
                cin.getline(Eproject,30);
                cout<<"Enter Employee Gender.(M/F)\n";
                cin>>Egender;
                while((Egender!='m')&&(Egender!='M')&&(Egender!='f')&&(Egender!='F'))
                {
                    cout<<"Please Enter M for Male. OR F for Female.\n";
                    cin>>Egender;
                }
                cout<<"Enter Employee Salary\n";
                cin>>Esalary;
                cout<<"Enter Employee Age\n";
                cin>>Eage;

                obj.InsertLast(Eid,Ename,Eaddress,Eproject,Egender,Esalary,Eage);
            break;
            case 3:
                cout<<"Enter Employee id\n";
                cin>>Eid;
                cin.ignore();
                cout<<"Enter Employee name\n";
                cin.getline(Ename,20);
                cout<<"Enter Employee Address\n";
                cin.getline(Eaddress,30);
                cout<<"Enter Employee Project\n";
                cin.getline(Eproject,30);
                cout<<"Enter Employee Gender.(M/F)\n";
                cin>>Egender;
                while((Egender!='m')&&(Egender!='M')&&(Egender!='f')&&(Egender!='F'))
                {
                    cout<<"Please Enter M for Male. OR F for Female.\n";
                    cin>>Egender;
                }
                cout<<"Enter Employee Salary\n";
                cin>>Esalary;
                cout<<"Enter Employee Age\n\n";
                cin>>Eage;

                cout<<"Enter the Position\n";
                cin>>iPos;

                obj.InsertAtPos(Eid,Ename,Eaddress,Eproject,Egender,Esalary,Eage,iPos);
            break;
            case 4:
                obj.DeleteFirst();
            break;
            case 5:
                obj.DeleteLast();
            break;
            case 6:
                cout<<"Enter the Position\n";
                cin>>iPos;
                obj.DeleteAtPos(iPos);
            break;
            case 7:
                obj.Display();
            break;
            case 8:
                iCount=obj.Count();
                cout<<"Total number of Employees are : "<<iCount;
            break;
            case 0:
                cout<<"Thank You For Using Application\n";
            break;
            default:
                cout<<"Wrong Choice!!!"<<endl;
        }
    }
    
    return 0;
}