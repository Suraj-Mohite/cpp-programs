#include<iostream>
using namespace std;
namespace c
{
    class demo
    {
        public:
        int i;
    };
    namespace d
    {
        int j=63;
    }
}

namespace cc
{
    class hello
    {
        public:
            int h;
    };
}


int main()
{
   /* using namespace c::d;
    c::demo cou;
    cou.i=10;
    cout<<cou.i<<"\n";
    //j=30;
    cout<<j;
    */
    
    cc::hello obj;
    obj.h=635;
    cout<<obj.h;

}