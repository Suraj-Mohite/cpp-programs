using namespace std;
#include<iostream>
#include<stdlib.h>

class demo
{
    public:
    int i;

    void* operator new(size_t number)
    {
        cout<<"allocating memory for your object"<<endl;
        void*p=malloc(number);
        return p;
    }

    void operator delete(void* q)
    {
        char ch='\0';
        cout<<"do you really want to deallocate memory y=0/n=1\n";
        cin>>ch;
        if(ch=='y')
        {
            free (q);
        }

    }

};

int main()
{
    demo*p=new demo;
    p->i=10;
    cout<<p->i<<endl;
    delete p;
}

