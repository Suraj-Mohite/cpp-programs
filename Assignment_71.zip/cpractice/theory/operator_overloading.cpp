/*
we can overload operator by two ways
1.by member function here in case of unary input is nothing coz of this->pointer it is first parameter in binary case this-> is first parameter hence we need to give only one parameter 
2.by using friend function if we want to access private members of class otherwise without friend function by normal function we can overload operator.in friend function there is not concept of this->pointer  because it is not member of class hence we need to give parameters here in case of unary there is only one parameter in binary more than one parameter depend on situation 
*/

#include<iostream>
using namespace std;

class demo
{
    public:
    int i=0;
    int j=0;
     demo(int a=20,int b=10)
     {
        this->i=a;
        this->j=b;
     }

     /*demo operator +()  //internally one parameter is this->obj
     {
         return *this;
     }*/

     demo operator -(demo op)
     {
         /*
         demo temp(0,0);
         temp.i=op1.i-op2.i;
         temp.j=op1.j-op2.j;
         return temp;*/
         return demo(this->i-op.i,this->j-op.j);
     }

     friend demo operator +(demo);
     friend demo operator -(demo);
     friend demo operator ++(demo);
     friend demo operator ++(demo,int);
     friend demo operator --(demo,int);
     friend demo operator ++(demo);
     friend demo operator --(demo);

     friend demo operator + (demo,demo);
     friend bool operator >(demo,demo);
     friend bool operator >=(demo,demo);
     friend bool operator <(demo,demo);
     friend bool operator <=(demo,demo);
     friend bool operator ==(demo,demo);
     friend bool operator !=(demo,demo);
};
    demo operator +(demo obj1)  //here internally one parameter is NOT this->obj because it is not class member hence we used friend concept and send one parameter as object. without friend concept also we can use operator overloading concept for naked function but in that sitaation we coulden't access private members of our class hence we have used friend concept here. and it is not function overloading because this + function is not part of same class.
     {
         demo temp(0,0);
         temp.i=obj1.i;
         temp.j=obj1.j;
         return temp;
     }

     demo operator -(demo op)
     {
         return demo(-op.i,-op.j);      //class name is imortant otherwise will give wrong output
     }

     demo operator ~(demo op)
     {
         return demo(~op.i,~op.j);
     }

     demo operator ++(demo op)  //preincrement
     {/*
         demo temp(0,0);
         temp.i=++op.i;
         cout<<temp.i<<"\n";
         temp.j=++op.j;
         cout<<temp.j<<"\n";
         return temp;*/
         return demo(++op.i,++op.j);
     }

     demo operator ++(demo op,int)  //postincrement //here second parameter should be int for compiler understanding difference between pre and post increament or decrement
     {
         op.i++;
         op.j++;
         return op;
     }
     demo operator --(demo op)  //predecrement
     {
         /*demo temp(0,0);
         //temp.i=--op.i;
         cout<<temp.i<<"\n";
         temp.j=--op.j;
         //cout<<temp.j<<"\n";
         return trmp;
         */
         return demo(--op.i,--op.j);
     }

     demo operator --(demo op,int)  //postdecrement
     {
         op.i--;
         op.j--;
         return op;
     }


     demo operator +(demo op1,demo op2)
     {
         /*
         demo temp(0,0);
         temp.i=op1.i+op2.i;
         temp.j=op1.j+op2.j;
         return temp;*/
         return demo(op1.i+op2.i,op1.j+op2.j);
     }
     
     demo operator *(demo op1,demo op2)
     {
         return demo(op1.i*op2.i,op1.j*op2.j);
     }
     demo operator /(demo op2,demo op1)
     {
         return demo(op2.i/op1.i,op2.j/op1.j);
     }

     bool operator >(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i>op2.i&&op1.j>op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i>op2.i&&op1.j>op2.j ? true : false);    //compound operator ?:
     }
     bool operator >=(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i>=op2.i&&op1.j>=op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i>=op2.i&&op1.j>=op2.j ? true : false);    //compound operator ?:
     }

     bool operator <(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i>op2.i&&op1.j>op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i<op2.i&&op1.j<op2.j ? true : false);    //compound operator ?:
     }
     bool operator <=(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i<=op2.i&&op1.j<=op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i<=op2.i&&op1.j<=op2.j ? true : false);    //compound operator ?:
     }
     bool operator ==(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i==op2.i&&op1.j==op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i==op2.i&&op1.j==op2.j ? true : false);    //compound operator ?:
     }
     bool operator !=(demo op1,demo op2)  // here return vaue is boolean
     {
         /*
         if(op1.i!=op2.i&&op1.j!=op2.j)
         {
             return true;
         }
         else
         {
             return false;
         }*/
        
        return (op1.i!=op2.i&&op1.j!=op2.j ? true : false);    //compound operator ?:
     }

int main()
{
    demo obj,ret(0,0);
    //cout<<obj.i<<"\t"<<obj.j<<endl;
    ret=+obj;
    cout<<"+obj = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=-obj;
    cout<<"-obj = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=~obj;
    cout<<"~obj = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=++obj;
    cout<<"++obj = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=obj++;
    cout<<"obj++ = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=--obj;
    cout<<"--obj = "<<ret.i<<"\t"<<ret.j<<"\n";
    ret=obj--;
    cout<<"obj-- = "<<ret.i<<"\t"<<ret.j<<"\n";

    demo obj2(5,6);
    ret=obj+obj2;  //obj.operator +(obj2) // for friend function +(obj,obj2)
    cout<<"Addition is "<<ret.i<<"\t"<<ret.j<<endl;
    ret=obj-obj2;  //obj.operator -(obj2) // for member function -(obj2)
    cout<<"substraction is "<<ret.i<<"\t"<<ret.j<<endl;
    ret=obj*obj2;  
    cout<<"multiplication is "<<ret.i<<"\t"<<ret.j<<endl;
    ret=obj2/obj;
    cout<<"division is "<<ret.i<<"\t"<<ret.j<<endl;

    if(obj>obj2)
        cout<<"obj is greater than obj2.\n";
    else
        cout<<"obj2 is greater than obj.\n";
    if(obj>=obj2)
        cout<<"obj is greater than obj2.\n";
    else
        cout<<"obj2 is greater than obj.\n";
    if(obj<obj2)
        cout<<"obj is less than obj2.\n";
    else
        cout<<"obj is greater than obj2.\n";
    if(obj<=obj2)
        cout<<"obj is less than obj2.\n";
    else
        cout<<"obj is greater than obj2.\n";
    
    
    demo obj3(20,300),obj4(20,300);
    obj3==obj4?cout<<"equal\n":cout<<"not equal\n";
    obj3!=obj4?cout<<"not equal\n":cout<<"equal\n";

  
}