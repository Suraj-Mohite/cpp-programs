using  namespace std;
#include<iostream>

class A
{
    public:
    void fun()
    {cout<<"A fun\n";}
};

class B:public A
{
    public:
    virtual void fun()
    {cout<<"B fun\n";}
};
class C:public B
{
    public:
    void fun()
    {cout<<"c fun\n";}
};

int main()
{
    cout<<"A "<<sizeof(A)<<endl;
    cout<<"B "<<sizeof(B)<<endl;
    cout<<"C "<<sizeof(C)<<endl;
    B*p;
    C obj;
    cout<<"A "<<sizeof(A)<<endl;
    cout<<"B "<<sizeof(B)<<endl;
    cout<<"C "<<sizeof(C)<<endl;
    p=&obj;
    p->fun();
    obj.fun();
    obj.A::fun();
    return 0;
}