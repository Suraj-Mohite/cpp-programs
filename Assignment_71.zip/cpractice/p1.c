#include<stdio.h>

struct students
{
   char name[20];
   char divi;
   int roll;
   int std;
  
};
struct students d1;
struct students fun()
   {
      struct students d2;
      printf("Please enter your name\n: ");
      gets(d2.name);
      printf("standard\n: ");
      scanf("%d",&d2.std);
     // printf("division\n: ");
      scanf("%c",&d2.divi);
      printf("\nroll no.\n: ");
      scanf("%d",&d2.roll);
      return(d2);
   }
int main()
{
   
    printf("you are in main\n");
    d1=fun();
    return 0;
}