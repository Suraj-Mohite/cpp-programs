#include<stdio.h>
#include<stdlib.h>
int main()
{
int ****p = NULL;
int i = 0, j = 0, k = 0, l = 0;
int first = 0, second = 0, third = 0, fourth = 0;
printf("Enter the dimensions\n");
scanf("%d%d%d%d",&first, &second, &third, &fourth);
p = (int****)malloc(first*sizeof(int***));
for(i=0; i<first; i++)
{
p[i] = (int***)malloc(sizeof(int**)*second);
}
for(i=0; i<first; i++)
{
for(j=0; j<second; j++)
{
p[i][j] = (int**)malloc(sizeof(int*)*third);
}
}
for(i=0; i<first; i++)
{
for(j=0; j<second; j++)
{
for(k=0; k<third; k++)
{
p[i][j][k] = (int*)malloc(sizeof(int)*fourth);
}
}
}
printf("Enter the elements\n");
for(i=0; i<first; i++)
{
for(j=0; j<second; j++)
{
for(k=0; k<third; k++)
{
for(l=0; l<fourth; l++)
{
scanf("%d",&p[i][j][k][l]);
}
}
}
}
printf("Elements of array are\n");
// Logic
for(i=0; i<first; i++)
{
for(j=0; j<second; j++)
{
for(k=0; k<third; k++)
{
for(l=0; l<fourth; l++)
{
printf("%d ",p[i][j][k][l]);
}
printf("\n");
}
printf("\n");
}
printf("\n");

}
//Deallocate memory of array
for(i=0;i<first;i++)
{
    for(j=0;j<second;j++)
    {
        for(k=0;j<third;k++)
        {
            free(p[i][j][k]);
        }
        free(p[i][j]);
    }
    free(p[i]);
}
free(p);
return 0;

}