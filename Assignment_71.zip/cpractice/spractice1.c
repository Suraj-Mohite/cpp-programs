#include<stdio.h>

struct students
{
   char name[20],div;
   int roll,std;
  
};
struct students d1;
struct students fun()
   {
       
      printf("Please enter your name\n: ");
      gets(d1.name);
      printf("standard\n: ");
      scanf("%d",&d1.std);
      printf("division\n: ");
      scanf("%c",d1.div);
      printf("roll no.\n: ");
      scanf("%d",d1.roll);
   }
int main()
{
    printf("you are in main\n");
    fun();
    return 0;
}