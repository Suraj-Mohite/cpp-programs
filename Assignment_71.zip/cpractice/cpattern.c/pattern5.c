
/*          *
           * *
          * * *
         * * * *
        * * * * *
*/
#include<stdio.h>
int main()
{    int i,j;
    for(i=1;i<=5;i++)
      {
          for(j=1;j<=5;j++)
          {
              if(j>=(6-i))
              {
                  printf("* ");//if there is space in line 17 printf then 1 space should be in line 21
              }                 //if in line 17 one space and in line 21 1 space output isdifferent pattern4

              else
              {
                  printf(" ");
              }
          }
          printf("\n");
      }
    
    return(0);
}