#include<stdio.h>
int main()
{
    int i,j,k=0,space,n;

    printf("Enter the number of rows: \n");
    scanf("%d",&n);
    for ( i = 1; i <=n; i++)
    {
        for ( j = 0; i <= n-i; j++)
        {
            printf(" ");
        }
        while(k!=(2*i-1))
        {
            if(k==0 || k==2*1-2)
            {
                printf("*");
            }
            else
            {
                printf(" ");
                k++;
            }
            k=0;
            printf("\n");
        }
    }

    for ( i = 1; i <=n; i++)
    {
        for ( j = 0; i <= n-i; j++)
        {
            printf(" ");
        }
        while(k!=(2*i-1))
        {
            if(k==0 || k==2*1-2)
            {
                printf("*");
            }
            else
            {
                printf(" ");
                k++;
            }
            k=0;
            printf("\n");
        }
    }
    return 0;
}