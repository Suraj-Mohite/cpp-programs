using namespace std;
#include<iostream>
int main()
{
    int i,j,k;
    for(i=1;i<=5;i++)
    {
        k=1;
        for(j=1;j<=9;j++)
        {
            if(j>=i&&j<=(10-i)&&k)
            {
                 cout<<"* ";
                 k=0;
            }
            else
            {
                cout<<"  ";
                k=1;
            }
        }
        cout<<"\n";
    }
    return 0;
}