using namespace std;
#include<iostream>
#include<cstring>

class car
{
    private:
      int price;
      int average;
      char colour[10];
      char brand[15];
    
    private:

       void setprice(int k)
        {
           price=k;
           cout<<"price of car is:"<<price<<"\n";
        }
    public:
        void setaverage(int p)
        {
            cout<<"enter aveage of car in km/hr. \n";
            cin>>average;
            cout<<"average of car in km/hr. is: \n"<<average;

            setprice(p);

        }

        void setcolour()
        {
            cout<<"enter colour of the car: \n";
            gets(colour);
            cout<<"colour of car is :"<<colour<<"\n";

        }
        car()
        {
            cout<<"inside constructor\n";

        }
         car(int a,int b)
        {
           // price=a,average=b;
            cout<<"inside constructor a+b= "<<a+b;
             
        }
         car(int k)
        {
            cout<<"inside constructor:"<<k;

        }
        ~car()
        {
            cout<<"\n\ninside detructor.";
        }

};

int main()
{
    car c1;
    car c2(63);
    car c3(665,98);
    c1.setcolour();
    return 0;
}