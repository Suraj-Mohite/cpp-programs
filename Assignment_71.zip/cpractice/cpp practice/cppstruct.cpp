using namespace std;
#include<iostream>
#include<cstring>
//void sub(date);
struct date
{
    int d,m,y;
    char month[4];
    char day[10];
    char name[20];
    float no1,no2;
}d4;
date d2;
void fun1()
{
    cout<<sizeof(d4)<<"\n"<<sizeof(d2)<<"\n";
}
void sub(date z)
{
  
    float z1;
    z1=z.no1-z.no2;
    if(z.no1>z.no2)
       {
          cout<<"substraction of given number is:"<<z1<<"\n\n";
       }
    else
    {
       cout<<"substraction of given number is:"<<-z1<<"\n\n";
       cout<<"ans is negative\t"<<-(-z1)<<"\n\n";
    }

    int i;
    for(i=0;i<5;i++)
    {
        cout<<"SURAJ"<<"\n";
    }
    
    
    strcpy(z.name,"Suraj Prakash Mohite.");
    cout<<"Your name is: "<<z.name<<"\n\n";


}

date add(date a)
{
    date ans;
    a.no1+a.no2;
    return(a);
}

date fun2()
{
    date D;
    //cout<<D.d<<"/"<<D.month<<"/"<<D.y<<"\n";
    cout<<"Enter Your date of birth dd/mm/yyyy:"<<"\n";
    cin>>D.d>>D.month>>D.y;
    //cout<<D.d<<"/"<<D.month<<"/"<<D.y<<"\n";
    return(D);
}
int main()
{
    char ch[5]={'a','b','c','d'};
    cout<<&ch<<"\n";
    cout<<ch[0]<<"\n";
    cout<<ch[1]<<"\n";
    cout<<ch[3]<<"\n\n";
    cout<<"enter your name\n\n";
    gets(d4.name);                              //use gets() to enter string  
    cout<<"your name is: "<<d4.name<<"\n\n";
    void gun(date);
    date d1,k,A,d3={12,01,1997};
    d1.d=12;
    strcpy(d1.month,"jan");
    d1.y=1997;
   // d2=d1;
    cout<<"your birthdate is:"<<d3.d<<"/"<<d3.m<<"/"<<d3.y<<"\n";
    cout<<"Your birthdate is:"<<d1.d<<"/"<<d1.month<<"/"<<d1.y<<"\n";
    fun1();             //take nothing return nothing
    k=fun2();            //take nothing return something
    cout<<"Your birthdate is:"<<k.d<<"/"<<k.month<<"/"<<k.y<<"\n";

    A.no1=68.3;
    A.no2=746.98;
    k=add(A);              //take something return something
    cout<<"sum is :"<<"\n"<<k.no1+k.no2<<"\n\n";
    cout<<"Enter first number:\n";
    cin>>k.no1;
    cout<<"Enter second number:\n";
    cin>>k.no2;

    gun(k);               //take something return nothing
    return 0;
}

void gun(date v)
{
    sub(v);              //take something return nothing global function
    int i=0;
    cout<<"enter a number: \n\n";
    cin>>i;
    if(i>0 && i<=10) 
     {
         cout<<"print marevellous "<<10-i<<" times\n";
        while (i<10)
            {
              cout<<"MARVELLOUS..."<<"\n";
              i++;
            }

     }
     else
     {
         cout<<"INFOSYSTEM"<<"\n";
     }
    cout<<"\nEnter today's day:"<<"\n";
    cin>>v.day;s
    cout<<"Todays day is:"<<v.day<<"\n\n";
    cout<<"...THE END...";

}