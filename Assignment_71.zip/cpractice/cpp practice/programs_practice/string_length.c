/* write aprogram which will take string (name) as an input and 
find length of the string without using main function 
and also print entered name in a function without using semicolon*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
#define without_main main
void no_semicolon(char p[]);
int without_main()
{
    char name[30];
    int length;
   
    printf("Enter your name : \n");
    gets(name);
   
    length=strlen(name);
    printf("length of your name= %s is : %d\n",name,length);
    no_semicolon(name);
}
/* printing entered name without using semicolon in function*/
/* send string as an agument*/

void no_semicolon(char p[])
{
    if(printf("%s\n",p))
    {}
}
