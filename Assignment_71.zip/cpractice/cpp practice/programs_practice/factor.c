#include<stdio.h>
#include<conio.h>

int main()
{
    int number,i,j,fact=1;
    printf("Enter the number: \n");
       for(j=1;j>0;j++)
       {
             scanf("%d",&number);
         if (number <0)
         { 
               printf("Please enter positive number\n");
               printf("Enter the number: \n");
         }
         else
         {
             for(i=number;i>=1;i--)
             {
                 fact=fact*i;
             }
             printf("answer of %d! is = %d ",number,fact);
            break; 
         }
       }

    return 0;         
}