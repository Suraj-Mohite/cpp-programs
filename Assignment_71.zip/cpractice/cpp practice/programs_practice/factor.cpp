using namespace std;
#include<iostream>

int main()
{
    int number,j,i,fact=1;
    cout<<"Enter the number: \n";
    for(j=1;j>0;j++)
    {
        cin>>number;
        if(number<0)
        {
            cout<<"Please enter positive number.\n";
            cout<<"Enter the number: \n";
        }
        else
        {
            for(i=number;number>0;i--)
            {
               fact=fact*i;
            }
            cout<<"answer of"<<number<<"!"<<"is"<<fact<<endl;
           break;
        }
        
    }
    return 0;
}