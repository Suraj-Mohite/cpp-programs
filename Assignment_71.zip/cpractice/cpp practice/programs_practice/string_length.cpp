/* write aprogram which will take string (name) as an input and 
find length of the string without using main function 
and also print entered name in a function without using semicolon*/

using namespace std;
#include<iostream>
#include<cstring>
#define no_main main
void no_semicolon(char s[]);

int no_main()
{
    char name[30];

    cout<<"Enter your name : \n";
    gets(name);
    int length;
    length=strlen(name);
    cout<<"length of your name "<<name<<" is "<<length<<endl;

    no_semicolon(name);
    return 0;
}

/* printing entered name without using semicolon in function*/
/* send string as an agument*/
void no_semicolon(char s[])
{
    if(cout<<s<<"\n")
    {}
}
