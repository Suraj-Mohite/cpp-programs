//area and perimeter of circle
using namespace std;
#include<iostream>
#define pi 3.14
void perimeter(float);      //global declaration of function
int main()
{
    float calculation(float);
    float r,a;
    cout<<"Enter radius of circle in meter\n";
    cin>>r;
    a=calculation(r);
    cout<<"Area of the circle is: "<<a<<" m^2"<<"\n";
    return 0;
}
float calculation(float radius)
{
    float area;
    area=pi*radius*radius;
    perimeter(radius);
    return(area);
}
void perimeter(float r) //we can use same variable in another function 
                         //here variable r is already declared in line no.9
{
    float p;
    p=2*pi*r;
    cout<<"Perimeter of the circle is : "<<p<<" m"<<"\n";
}