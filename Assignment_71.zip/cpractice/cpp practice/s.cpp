using namespace std;
#include<iostream>

struct maths
{
    int a,b;
    void add1(int x,int y)
    {
        a=x,b=y;
    }

    maths add(maths c)
    {
        maths z;
        z.a=a+c.a;
        z.b=b+c.b;
        return(z);

    }

};

int main()
{
    maths c1,c2,c3;
    c1.add1(10,5);
    c2.add1(8,6);
    c3=c2.add(c1);
    cout<<"answer is"<<c3.a<<" "<<c3.b;
    return 0;
}