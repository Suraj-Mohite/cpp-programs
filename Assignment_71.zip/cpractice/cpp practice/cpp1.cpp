//check entered year is leap year or not
using namespace std;
#include<iostream> 
void check_leap(int);
int main()
{
    int year=0;
    cout<<"Enter any year\n";
    cin>>year;
    check_leap(year);
}

void check_leap(int check)
{
    if (check % 400==0)
    {
        cout<<"Entered year "<<check<<" is leap year";
    }
    else
      if (check % 4==0)
      {
        cout<<"Entered year "<<check<<" is leap year";
      }
      else
        cout<<"Entered year "<<check<<" is not leap year";
}