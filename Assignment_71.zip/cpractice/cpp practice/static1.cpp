#include<iostream>
using namespace std;
class demo
{
    private:
    int i;
    static int j;
    
    public:
    int no;
    static int k;
    static void gun(int b=63)
    {
        j=b;
        cout<<j<<"\n";
    }
    static int gun1(int b)
    {
        return(j=b);
        //cout<<j<<"\n";
    }
     void gun2()
     {
         cout<<"suraj";
     }
     demo(int b=5)
     {
         cout<<"in\n"
     }
    protected:
    int v;

};
class derived:protected demo
{
     public:
     int no1;
     derived(int w)
     {
         v=w;
         cout<<v<<"\n";
     }
};
class derived2:public derived
{
      derived2(int w=54)
      {
         no1=w;
          cout<<no1<<"\n";
      }
}

//int demo::j=88;
//int demo::k=971;

int main()
{
    int i;

   demo obj;
   derived obj1(55);
   derived2 der();
  // cout<<obj1.no<<"\n";
  return 0;
}
