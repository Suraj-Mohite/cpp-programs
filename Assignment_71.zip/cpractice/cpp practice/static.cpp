#include<iostream>
using namespace std;
class parent
{
    private:
    int i;
    char arr[20];
    static int k;
    
    public:
    int j;
    float f;

    static void gun(int g=64)
    {
        k=g;
        //i=g;

        cout<<k<<"\n";
       // cout<<i<<"\n";

    }

    parent()
    {
        cout<<"default constructor\n";
    }

    int fun(int a=63,int b=94)
    {
        i=a;
        j=b;
        return(i=i+j);
    }
    parent(int i,int j)
    {
        this->i=i;
        this ->j=j;
        j=i+j;
        cout<<j<<endl;
    }
    parent(parent &ref)
    {
        cout<<"copy constructor\n";
        this->i=ref.i;
        this-> j=ref.j;
        i=i+j;
        cout<<i<<"\n";
        cout<<j<<"\n";
    }

     
    ~parent()
    {
        cout<<"in destructor"<<endl;
    }

    protected:
    int s,p,m;
    
}obj1;

//parent obj2;

int main()
{
    int i=766,j=96;
    int &ref=i;
    cout<<ref<<endl;
    cout<<i<<endl;
    cout<<&i<<endl;
    cout<<&ref<<endl;

    parent obj2(65,74);
    parent *p=new parent(98,74);
     // i=p->fun(98,74);
    //cout<<i<<endl;
    obj2.gun();
    parent::gun(33);

    delete (p);
    parent obj3(obj2);
    //obj3.fun(65,98,55);
    //cout<<i<<endl<<j<<endl;
}