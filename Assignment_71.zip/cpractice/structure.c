#include<stdio.h>
#include<string.h>
struct books
{
    char name[20];
    char auther[20];
    int id_number;
    float price;
};
void main()
{
   struct books b1;
   //strcpy(b1.name,"c++ programming");
  // strcpy(b1.auther,"saurabh shukla");
   //b1.id_number=133014;
   b1.price=963;
   printf("%d",b1.price);
   //printf("hello");

}