#include<stdio.h>
//void acircle(void); //take nothing return nothing
int prect(int,int);  // take something return something,global function

 int main()
{ 
    int m=0,n=0, u;;
    float a=0.0;
    void acircle(void); //take nothing return nothing
    void arect(int,int);//take something return nothing
    float add(void); //take nothing return something 
     u=sizeof('a');//ANSI STANDARD
     printf("%d\n",u);
   //clrscr();
    //g();
    acircle();
    printf("enter length and width of rectagle\n");
    scanf("%d%d",&m,&n);
    arect(m,n);
    a=add();
    printf("sum = %d\n",a);

    return 0;
    
}

void acircle()
{
    float r=0.0,s=0.0;
    printf("Enter the radius of circle in meter= \n");
    scanf("%f",&r);
    s=3.14*r*r;
    printf("Area of the circle is= %f m^2\n",s);
  
}
void arect(int x,int y)
{
    int t=0,q=0;
    t=x*y;
    printf("area of rectangle is = %d m^2 \n",t);
    q=prect(x,y);
    printf("perimeter of rectangle is=%d\n",q);
}
float add()
{
    float l=0.0,k=0.0,j=0.0;
    printf("Enter two no.= \n");
    scanf("%f%f",&l,&j);

    k=l+j;
    return(k);
}
int prect(int f,int j)
{
    int w;
    w=2*(f+j);
    return(w);
}
/*void g()
{
 printf("in g function\n"); 
 void acircle();
}*/