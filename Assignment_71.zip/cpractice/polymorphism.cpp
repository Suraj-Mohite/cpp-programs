#include<iostream>
using namespace std;

class A
{
    /* ******polymorphism ****** */
    public:
    /* function overloading*/

    //by changing number of arguments
       void fun(int x,int y)  
       { cout<<"You are in base fun 1\n";}
       virtual void fun(int a)
       { cout<<"you are in base fun 2\n";}
      
    //by changing data type of function argument
      void fun(float b)   
       {cout<<"you are in base fun 3\n";}

    //by changing sequence of data type of function argument fun 4 and fun 5
       void fun(float a,double b)  
       {cout<<"you are in fun 4\n";}
       void fun(double b,float a)
       {cout<<"You are in fun 5\n";}
       void gun()
       {cout<<"base gun\n";}
       
       int i=100;
};
class parent
{
    public:
    virtual void sun()=0;   //it is purevertual function.if there is atleast one pure virtual function then this class is abstract class we can not create its object but you can create its pointer 
};
class B:public A,public parent   
{
    public:
      int i=200;
      void fun(float a)  //Redefinition
      {cout<<"you are in derived class B redefination\n";}
      void fun(int a)  //overriding
      {cout<<"you are in derived class B overriding due to virtual word\n";}
      void gun(int a)  //method hiding OR function hiding it is not polymorphism because classes are different.
       {cout<<"derived gun method hiding\n";}
    
      void sun()
       {cout<<"derived sun function (due to abstract class)\n\n";}
};

int main()
{
    A *p;
    A obj1;
    B obj;
    obj1.fun(16);
    obj1.fun(63,2);
    obj1.fun(65.5f);
    obj1.fun(65.5f,6.3);
    obj1.fun(44.1,65.5f);
    obj.fun(3.6f);
    obj.A::fun(3.6f);
    cout<<obj.i<<endl;   //derived class characteristics Redefination
    cout<<obj1.i<<endl;  //parent class characteristics
    cout<<obj.A::i<<endl; //calling parents characteristics using derived redefine obj

    p=&obj;  //upcasting(means pointer of parent class whose size is smaller than derived class is pointing to object of derived class)

    p->fun(3.2,56.3f); //normally function of parent class calling by using pointer of parent class
    p->fun(2);   //calling derived function by using parent pointer but output is parent function if we dont use virtual keyward
    obj.gun(6);
    cout<<"\n\n";

    //FOR CLASS PARENT
    parent*ptr;
    ptr=&obj;
    ptr->sun();
   /* B*pp;
    pp=&obj;   //calling by using pointer of derived class (nothing special)
    pp->sun();*/

    return 0;
}