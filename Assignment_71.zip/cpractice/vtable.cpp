using namespace std;
#include<iostream>


class base
{
    public:
        int i,j;
        base()
        {
            cout<<"base constructor\n";
        }
        virtual ~base()
        {
            cout<<"base destructor\n";
        }

        void fun()
        {
            cout<<"base fun\n";
        }
        virtual void gun();
        virtual void sun()
        {
            cout<<"base sun\n";
        }
        void run()
        {
            cout<<"base run\n";
        }
};

void base :: gun()
{
    cout<<"base gun\n";
}

class derived:public base
{
    public:
    derived()
        {
            cout<<"derived constructor\n";
        }
        ~derived()
        {
            cout<<"derived destructor\n";
        }
    void fun()
    {
        cout<<"derived fun\n";
    }
    void gun()
    {
        cout<<"derived gun\n";
    }
    virtual void run()
    {
        cout<<"derived run\n";
    }
};

int main()
{
    int i;
    base *bp=new derived;
    delete bp;
    
    /*derived dobj;
    int*p=(int*)(&dobj);
    int*vptr=(int*)(*p);
    cout<<"address of vtable:"<<vptr<<endl;
    void(*fp)();
    for(i=0;i<=2;i++)
    {
        fp=(void(*)())(*(vptr+i)); 
        fp();
    }*/
    return 0;
}