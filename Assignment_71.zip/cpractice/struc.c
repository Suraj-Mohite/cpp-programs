#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct student
{
    char name[20];
    char city[20];
    int mob;
    float marks;
};

int main()
{
    int i,n;
    struct student obj[2];
    printf("Enter number of students:");
    scanf("%d",&n);
    struct student*p=NULL;
        p=(struct student*)malloc(n*sizeof(struct student));
    for(i=0;i<n;i++)
    {
        printf("Enter name of student no.%d :",i+1);
        fflush(stdin);
        gets(p[i].name);
        printf("Enter city of student no.%d :",i+1);
        fflush(stdin);
        gets(p[i].city);
        printf("Enter mob no. of student no.%d :",i+1);
        scanf("%d",&p[i].mob);
        printf("Enter marks of student no.%d :\n",i+1);
        scanf("%f",&p[i].marks);
    }
    for(i=0;i<n;i++)
    {
        printf("name of student no.%d is %s \n" ,i+1,p[i].name);
        printf("city of student no.%d is %s \n" ,i+1,p[i].city);
        printf("mob no. of student no.%d is %d \n",i+1,p[i].mob);
        printf("marks of student no.%d is %.3f \n",i+1,p[i].marks);
        printf("\n");
        printf("\n");
    }
    return 0;
}