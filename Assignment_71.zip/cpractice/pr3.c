#include<stdio.h>

int main()
{
    int a=0;
    int b=0;
    int c=0;
    int*p1=&a;
    int*p2=&b;
    
    printf("Enter the first numbers a= \n");
    scanf("%d",&a);

    printf("Enter the second number b= \n");
    scanf("%d",&b);

    c=a+b;
    printf("Addition of %d and %d is = %d \n\n\n",a,b,c);

    printf("address of a is= %d \naddress of b is=%d \naddress of c is=%d \n\n\n",&a,&b,&c);
    printf("%d\n%d",p1,p2);
   // c=p1 + p2;
    printf("addition of address of a= %d\naddress of b= %d\nis = %d\n ",p1,p2);

    return 0;


}