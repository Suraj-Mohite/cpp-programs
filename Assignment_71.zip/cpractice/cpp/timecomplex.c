/*Accept number from user and display its*/

#include<stdio.h>
void Fact(int);

void Fact(int iNo)
{
    int iCnt=0;
    int iRet=iNo/2;
    for(iCnt=1;iCnt<=iNo/4;iCnt++)
    {
        if(iNo%iCnt==0)
        {
            printf("%d\t",iCnt);
        }
        if(iNo%iRet==0)
        {
            printf("%d\t",iRet);
        }
        iRet--;
    }
}

int main()
{
    int iValue=0;

    printf("Enter number ");
    scanf("%d",&iValue);

    Fact(iValue);

    return 0;
}