import java.lang.*;
public class Check
{
	public static int Disarium(int iNo)
	{
		public int iCnt=0,iTempCnt=0,iTempNo=iNo,iSum=0,iMult=1,iDigit=0;
		while(iNo!=0)
		{
			iNo=iNo/10;
			iCnt++;
		}
		iTempCnt=iCnt;
		iNo=iTempNo;
		while(iNo!=0)
		{
			iDigit=iNo%10;
			for(iCnt=iTempCnt;iCnt>0;iCnt--)
			{
				iMult=iMult*iDigit;
			}
			iTempCnt--;
			iSum=iSum+iMult;
			iMult=1;
			iNo=iNo/10;
		}
		if(iSum==iTempNo)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}	
}

class Demo
{
	public static void main(String arg[])
	{
		Check obj=new Check;
		System.out.println(obj.Disarium(175));
	}
}