using namespace std;

#include<iostream>

class maths
{
    private:
        int no1;
        int no2;

    public:
        maths()
        {
            this ->no1=0;
            this ->no2=0;
        }

         maths(int value1,int value2)
         {
             this ->no1= value1;
             this ->no2= value2;
         }

         maths(maths &ref)
         {


         }

         ~maths()
         {
             cout<<"inside dstructor\n";
         }

    int add()
    {
        int ans=0;
        ans=this->no1 + this->no2;
        return ans;
    }

    int sub()
    {
        int ans=0;
        ans=this->no1-this->no2;
        return ans;
    }
};

int main()
{
    cout<<"inside main\n";

    maths obj1();
    maths obj2(20,5);
    maths obj3(obj2);

    int ret=0;

    ret=obj1.add();
    cout<<"addition is"<<ret<<"\n";
    
    ret=obj2.add();
    cout<<"addition is"<<ret<<"\n";

    return 0;
}