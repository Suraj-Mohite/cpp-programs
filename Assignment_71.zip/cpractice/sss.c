#include<stdio.h>
main()
{
    int s[5]={60,3,5,3,63,33};
    int p,y,z=0;
    float f=0.0;
    double d=52.69;
    char c='a';
   // x=x+s;
   // y=20>26<6>963;
   // p=20|30;
   // z=~12;  
  printf("%d\n\n",s);
   printf("%d\n\n",&s);
  printf("%d\n\n",s+1);
   printf("%d\n\n",&s+1);
   printf("%d\n\n",s[3]);
   printf("%d\n\n",s[3+1]);
   printf("%d\n\n",s[3]+1);
   printf("%d\n\n",s[4]);
}