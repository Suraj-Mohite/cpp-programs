#include<stdio.h>

struct students
{
   char name[20];
   char div;
   int roll;
   int std;
  
};
 students d1;
 students fun()
   {
       students d2;
      cout<<"Please enter your name\n: ";
      gets(d2.name);
      cout<<"standard: ";
      cin>>d2.std;
      cout<<"division: ";
      cin>>d2.div;
      cout<<"roll no.";
      cin>>d2.roll;
      return(d2);
   }
int main()
{
   
    printf("you are in main\n");
    d1=fun();
    return 0;
}