#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#define MAX_FILE 100
#define FILE_SiZE 1024

#define READ 4
#define WRITE 2

#define REGULAR 1
#define SPECIAL 2

typedef struct Inode
{
    char File_Name[50];
    int Inode_Number;
    int File_Size;
    int File_Type;
    int ActualFileSize;
    int Link_Count;
    int Reference_Count;
    char*Data;
    struct Inode*Next;
}INODE,*PINODE,**PPINODE;

PINODE Head=NULL;

typedef struct FileTable
{
    int Read_Offset;
    int Write_Offset;
    int Count;
    int Mode;
    PINODE iptr;
}FILETABLE,*PFILETABLE;

struct UFDT
{
    PFILETABLE ufdt[MAX_FILE];
}UFDTobj;

struct SuperBlock
{
    int TotalInode;
    int FreeInode;
}Super_obj;

void CreateSuperBlock()
{
    Super_obj.TotalInode=MAX_FILE;
    Super_obj.FreeInode=MAX_FILE;

    printf("Super block Created Successfully.\n");
}

void CreateUFDT()
{
    int i=0;
    for(i=0;i<MAX_FILE;i++)
    {
        UFDTobj.ufdt[i]=NULL;
    }
    printf("UFDT created successfully\n");
}

void CreateDILB()
{
    int i=1;
    PINODE Temp=Head;
    PINODE Newn=NULL;
    while(i<=MAX_FILE)
    {
        Newn=new INODE;
        Newn->Inode_Number = i;
        Newn->File_Size = FILE_SiZE;
        Newn->File_Type = 0;
        Newn->ActualFileSize = 0;
        Newn->Link_Count = 0;
        Newn->Reference_Count = 0;
        Newn->Data = NULL;
        Newn->Next = NULL;

        if(Head==NULL)
        {
            Head=Newn;
            Temp=Head;
        }
        else
        {
            Temp->Next=Newn;
            Temp=Temp->Next;
        }
        i++;      
    }
    printf("DILB created succesfully!!\n");
}

void SetEnvironment()
{
    CreateDILB();
    CreateUFDT();
    CreateSuperBlock();
    printf("Environment For Virtual File System Set Successfully\n");
}

bool CheckFile(char*name)
{
    PINODE Temp=Head;
    while(Temp!=NULL)
    {
        if(Temp->File_Type!=0)
        {
            if(strcmp(Temp->File_Name,name)==0)
            {
                break;
            }
        }
       Temp=Temp->Next;
    }

    if(Temp==NULL)
    {
        return false;
    }
    else
    {
        return true;
    }
    
}

int CreateFile(char*name,int Permission)
{
    if((Permission>READ+WRITE)||(name==NULL)||(Permission<WRITE))
    {
        return -1;
    }

    bool bret=CheckFile(name);
    if(bret==true)
    {
        printf("File Already Exist.\n");
        return -1;
    }
    
    int i=0;
    for(i=0;i<MAX_FILE ;i++)
    {
        if(UFDTobj.ufdt[i]==NULL)
        {
            break;
        }
    }

    if(i==MAX_FILE)
    {
        printf("Unable to get entry in UFDT\n");
        return -1;
    }
    
    UFDTobj.ufdt[i]=new FILETABLE;
    
    UFDTobj.ufdt[i]->Read_Offset=0;
    UFDTobj.ufdt[i]->Write_Offset=0;
    UFDTobj.ufdt[i]->Mode=Permission;
    UFDTobj.ufdt[i]->Count=1;

    PINODE Temp=Head;

    while(Temp!=NULL)
    {
        if(Temp->File_Type==0)
        {
            break;
        }
        Temp=Temp->Next;
    }

    UFDTobj.ufdt[i]->iptr=Temp;
    strcpy(UFDTobj.ufdt[i]->iptr->File_Name,name);
    UFDTobj.ufdt[i]->iptr->File_Type=REGULAR;
    UFDTobj.ufdt[i]->iptr->ActualFileSize=0;
    UFDTobj.ufdt[i]->iptr->Link_Count=1;
    UFDTobj.ufdt[i]->iptr->Reference_Count=1;

    UFDTobj.ufdt[i]->iptr->Data=(char*)malloc(sizeof(FILE_SiZE));
    Super_obj.FreeInode--;

    return i;
}

void DisplayHelp()
{
    printf("\n--------------------------------------------------------------------\n");
    printf("ls    :  To list out all the File.\n");
    printf("clear :  To clear the Console.\n");
    printf("open  :  To open existing File.\n");
    printf("close :  To close the Opened File.\n");
    printf("read  :  To read the Contents of File.\n");
    printf("write :  To write the data into File.\n");
    printf("write :  To write the data into File.\n");
    printf("creat :  To create regular File.\n");
    printf("rm    :  To delete regular File.\n");
    printf("--------------------------------------------------------------------\n");
}
void ManPage(char*str)
{
    if(strcmp(str,"open")==0)
    {
        printf("Description: It is used to open the existing File.\n");
        printf("Usage : open File_name Mode\n");
    }
    else if(strcmp(str,"close")==0)
    {
        printf("Description: It is used to close the opened File.\n");
        printf("Usage : close File_name\n");
    }
    else if(strcmp(str,"ls")==0)
    {
        printf("Description: It is used to list out all names of Files.\n");
        printf("Usage : ls\n");
    }
    else if(strcmp(str,"creat")==0)
    {
        printf("Description: It is used to creat regular File.\n");
        printf("Usage : creat File_Name Permission\n");
    }
    else if(strcmp(str,"rm")==0)
    {
        printf("Description: It is used to delete regular File.\n");
        printf("Usage : rm File_Name\n");
    }
    else if(strcmp(str,"write")==0)
    {
        printf("Description: It is used to write in regular File.\n");
        printf("Usage : write File_Descriptor\n");
        printf("After the command Please Enter the Data\n");
    }
    else
    {
        printf("Man Page Not Found\n");
    }
    
}

int WriteFile(int fd,char*arr,int(size))
{
    if(UFDTobj.ufdt[fd]==NULL)
    {
        printf("NO file available at that file descriptor.\n");
        return -1;
    }
    if(UFDTobj.ufdt[fd]->Mode==READ)
    {
        printf("File is not in Write mode.\n");
        return -1;
    }
    strncpy(((UFDTobj.ufdt[fd]->iptr->Data)+(UFDTobj.ufdt[fd]->Write_Offset)),arr,size);
    UFDTobj.ufdt[fd]->Write_Offset=UFDTobj.ufdt[fd]->Write_Offset+size;
    return size;
    
}
void ReadFile(int fd,char*arr,int(size))
{
    if(UFDTobj.ufdt[fd]==NULL)
    {
        printf("NO file available at that file descriptor.\n");
        return;
    }
    if(UFDTobj.ufdt[fd]->Mode==WRITE)
    {
        printf("File is not in Read mode\n");
        return;
    }
    strncpy(((UFDTobj.ufdt[fd]->iptr->Data)+(UFDTobj.ufdt[fd]->Write_Offset)),arr,size);
    UFDTobj.ufdt[fd]->Write_Offset=UFDTobj.ufdt[fd]->Write_Offset+size;  
}
void DeleteFile(char*str)
{
    bool bret=CheckFile(str);
    if(bret==false)
    {
        printf("There is No such file.\n");
        return;
    }
    int i=0;
    for(i=0;i<MAX_FILE;i++)
    {
        if(strcmp(UFDTobj.ufdt[i]->iptr->File_Name,str)==0)
        {
            break;
        }
    }
    UFDTobj.ufdt[i]->Read_Offset=0;
    UFDTobj.ufdt[i]->Write_Offset=0;

    strcpy(UFDTobj.ufdt[i]->iptr->File_Name,"");
    UFDTobj.ufdt[i]->iptr->File_Type=0;
    UFDTobj.ufdt[i]->iptr->ActualFileSize=0;
    UFDTobj.ufdt[i]->iptr->Link_Count=0;
    UFDTobj.ufdt[i]->iptr->Reference_Count=0;

    free(UFDTobj.ufdt[i]->iptr->Data);
    UFDTobj.ufdt[i]->iptr->Data=NULL;
    free(UFDTobj.ufdt[i]);

    UFDTobj.ufdt[i]=NULL;
    Super_obj.FreeInode++;

}
void LS()
{
    PINODE Temp=Head;
    while(Temp!=NULL)
    {
        if(Temp->File_Type!=0)
        {
            printf("%s\n",Temp->File_Name);
        }
        Temp=Temp->Next;
    }
}
int main()
{
    char str[80];
    char command[4][80];
    int iCount=0;
    
    printf("Customised Virtual File System\n\n");
    SetEnvironment();

    while(1)
    {
        printf("Customised VFS:> ");
        fgets(str,80,stdin);
        fflush(stdin);
        iCount=sscanf(str,"%s%s%s%s",command[0],command[1],command[2],command[3]);
        
        if(iCount==1)
        {
            if(strcmp(command[0],"help")==0)
            {
                DisplayHelp();
            }
            else if(strcmp(command[0],"cls")==0)
            {
                system("cls");
            }
            else if(strcmp(command[0],"exit")==0)
            {
                printf("Thank You For Using Application.\n");
                break;
            }
            else if(strcmp(command[0],"ls")==0)
            {
                LS();
            }
            else
            {
                printf("ERROR:Wrong Command!!!\n");
            }
        }
        else if(iCount==2)
        {
            if(strcmp(command[0],"man")==0)
            {
                ManPage(command[1]);
            }
            else if(strcmp(command[0],"rm")==0)
            {
                DeleteFile(command[1]);
            }
            else if(strcmp(command[0],"write")==0)
            {
                char arr[FILE_SiZE]={'\0'};
                printf("Enter the Data To Write in File.\n");
                fgets(arr,FILE_SiZE,stdin);
                fflush(stdin);
                int iRet=WriteFile(atoi(command[1]),arr,strlen(arr)-1);
                if(iRet==-1)
                {
                    printf("No Data Written.\n");
                }
                else
                {
                    printf("%d byte has been written Successfully in File.\n",iRet);
                }
            }

        }
        else if(iCount==3)
        {
            if(strcmp(command[0],"creat")==0)
            {
                int fd=CreateFile(command[1],atoi(command[2]));
                if(fd==-1)
                {
                    printf("Unable to create file.\n");
                }
                else
                {
                    printf("File is successfully Created with file descriptor %d.\n",fd);
                }
                
            }
        }
        else if(iCount==4)
        {}
        else
        {
            printf("Bad Command Or File Name\n");
        }
        
    }
    return 0;
}