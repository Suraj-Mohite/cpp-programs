#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<io.h>

#define MAXINODE 50
#define MAXFILESIZE 2048

#define READ 1
#define WRITE 2

#define REGULAR 1
#define SPECIAL 2

#define START 0
#define CURRENT 1
#define END 2

typedef struct iNode
{
    char FileName[50];
    int InodeNumber;
    int FileSize;
    int FileActualSize;
    int FileType;
    char*Buffer;
    int LinkCount;
    int ReferenceCount;
    int Permission;
    struct iNode*Next;
}INODE,*PINODE,**PPINODE;

PINODE Head=NULL; //Global variable

typedef struct FileTable
{
    int count;
    int ReadOffset;
    int WriteOffset;
    int Mode;//1 2 3
    PINODE ptrinode;
}FILETABLE,*PFILETABLE;

typedef struct ufdt
{
    PFILETABLE ptrFileTable;
}UFDT;

UFDT UFDTarr[MAXINODE];

typedef struct SuperBlock
{
    int TotalInode;
    int FreeInode;
}SUPERBLOCK,*PSUPERBLOCK;

SUPERBLOCK SUPERBLOCKObj;
void CreateDILB()
{
    int i=1;
    PINODE newn=NULL;
    PINODE Temp=Head;
    
    while(i<=MAXINODE)
    {
        newn=(PINODE)malloc(sizeof(INODE));
        
        newn->InodeNumber=i;
        newn->FileSize=0;
        newn->FileActualSize=MAXFILESIZE;
        newn->FileType=0;
        newn->ReferenceCount=0;
        newn->LinkCount=0;

        newn->Buffer=NULL;
        newn->Next=NULL;

        if(Temp==NULL)
        {
            Head=newn;
            Temp=newn;
        }
        else
        {
            Temp->Next=newn;
            Temp=Temp->Next;
        }

        i++;
    }
    printf("DILB Created Successfully..\n");
}

void InitialiseUFDT()
{
    int i=0;
    while(i<MAXINODE)
    {
        UFDTarr[i].ptrFileTable=NULL;
        i++;
    }
    printf("UFDT initialised..\n");
}
void InitialiseSuperblock()
{
    SUPERBLOCKObj.TotalInode=MAXINODE;
    SUPERBLOCKObj.FreeInode=MAXINODE;

    printf("Super block initialised..\n");
}

void SetEnvironment()
{
    CreateDILB();
    InitialiseSuperblock();
    InitialiseUFDT();
}

//This Function is used to find whether file name is already exist or not
PINODE Get_Inode(char*name)
{
    PINODE Temp=Head;
    if(name==NULL)
    {
        return NULL;
    }
    while(Temp!=NULL)
    {
        if(strcmp(Temp->FileName,name)==0)
            break;

        Temp=Temp->Next;
    }

    return Temp;
}

//Create function Returns FILE descrioptor
int CreateFile(char*name,int permission)
{
    if((name==NULL)||(permission>3)||(permission<1))
    {
        return -1;
    }
    if(SUPERBLOCKObj.FreeInode==0)
    {
        return -2;
    }
    
    if((Get_Inode(name))!=NULL)
    {
        return -3;
    }

    (SUPERBLOCKObj.FreeInode)--;

    PINODE Temp=Head;
    int i=0;

    while(Temp!=NULL)
    {
        if(Temp->FileType==0)
        {
            break;
        }
        Temp=Temp->Next;
    }

    while(i<MAXINODE)
    {
        if(UFDTarr[i].ptrFileTable==NULL)
            break;
        i++;
    }
    
    UFDTarr[i].ptrFileTable=(PFILETABLE)malloc(sizeof(FILETABLE));

    if(UFDTarr[i].ptrFileTable==NULL)
    {
        return -4;
    }

    UFDTarr[i].ptrFileTable->count=1;
    UFDTarr[i].ptrFileTable->Mode=permission;
    UFDTarr[i].ptrFileTable->ReadOffset=0;
    UFDTarr[i].ptrFileTable->WriteOffset=0;

    UFDTarr[i].ptrFileTable->ptrinode=Temp;

    strcpy(UFDTarr[i].ptrFileTable->ptrinode->FileName,name);
    UFDTarr[i].ptrFileTable->ptrinode->FileType=REGULAR;
    UFDTarr[i].ptrFileTable->ptrinode->ReferenceCount=1;
    UFDTarr[i].ptrFileTable->ptrinode->LinkCount=1;
    UFDTarr[i].ptrFileTable->ptrinode->FileSize=MAXFILESIZE;
    UFDTarr[i].ptrFileTable->ptrinode->FileActualSize=0;
    UFDTarr[i].ptrFileTable->ptrinode->Permission=permission;
    UFDTarr[i].ptrFileTable->ptrinode->Buffer=(char*)malloc(MAXFILESIZE);

    
    return i;
}

int Open_File(char*name,int mode)
{
    int i=0;
    if(name==NULL||mode<1||mode>3)
        return -1;
    
    PINODE Temp=NULL;
    Temp=Get_Inode(name);
    if(Temp==NULL)
        return -2;
    if(Temp->Permission<mode)
        return -3;
    
    while(i<MAXINODE)
    {
        if(UFDTarr[i].ptrFileTable==NULL)
            break;
        i++;
    }
    UFDTarr[i].ptrFileTable=(PFILETABLE)malloc(sizeof(FILETABLE));
    if(UFDTarr[i].ptrFileTable==NULL)
        return -1;
    UFDTarr[i].ptrFileTable->count=1;
    
    if(mode==READ+WRITE)
    {
        UFDTarr[i].ptrFileTable->ReadOffset=0;
        UFDTarr[i].ptrFileTable->WriteOffset=0;       
    }
    else if(mode==READ)
    {
        UFDTarr[i].ptrFileTable->ReadOffset=0;
    }
    else if(mode==WRITE)
    {
        UFDTarr[i].ptrFileTable->WriteOffset=0;
    }
    UFDTarr[i].ptrFileTable->ptrinode=Temp;

    (UFDTarr[i].ptrFileTable->ptrinode->ReferenceCount)++;
    return i;
}
int GetFdFromName(char*name)
{
    int i=0;

    if(Get_Inode(name)==NULL)
        return -1;
    if(name==NULL)
        return -1;
    
    while(i<MAXINODE)
    {
        if(strcmp(UFDTarr[i].ptrFileTable->ptrinode->FileName,name)==0)
            break;
        i++;
    }
    return i;
}
int Write_File(int fd,char*arr,int isize)
{
    if(((UFDTarr[fd].ptrFileTable->Mode)!=WRITE)&&((UFDTarr[fd].ptrFileTable->Mode)!=READ+WRITE))
        return -1;

    if(((UFDTarr[fd].ptrFileTable->ptrinode->Permission)!=WRITE)&&((UFDTarr[fd].ptrFileTable->ptrinode->Permission)!=READ+WRITE))
        return -1;
    if((UFDTarr[fd].ptrFileTable->WriteOffset==MAXFILESIZE))
        return -2;
    if(UFDTarr[fd].ptrFileTable->ptrinode->FileType!=REGULAR)
        return -3;
    
    strncpy(((UFDTarr[fd].ptrFileTable->ptrinode->Buffer)+(UFDTarr[fd].ptrFileTable->WriteOffset)),arr,isize);

    UFDTarr[fd].ptrFileTable->WriteOffset=UFDTarr[fd].ptrFileTable->WriteOffset+isize;

    UFDTarr[fd].ptrFileTable->ptrinode->FileActualSize=(UFDTarr[fd].ptrFileTable->ptrinode->FileActualSize)+isize;
    
    return isize;

}

//this function accept file Descriptor char array, and size of data we have to read
int Read_File(int fd,char*arr,int isize)
{
    if((UFDTarr[fd].ptrFileTable->Mode!=READ)&&(UFDTarr[fd].ptrFileTable->Mode!=READ+WRITE))
        return -1;
    
    if((UFDTarr[fd].ptrFileTable->ptrinode->Permission!=READ)&&(UFDTarr[fd].ptrFileTable->ptrinode->Permission!=READ+WRITE))
        return -1;
    
   // if(UFDTarr[fd].ptrFileTable->ptrinode->)
    if(UFDTarr[fd].ptrFileTable->ptrinode->FileType!=REGULAR)
        return -3;


}
void ls()
{
    PINODE Temp=Head;

    if(SUPERBLOCKObj.FreeInode==MAXINODE)
    {
        printf("ERROR:There are no files.\n");
        return;
    }

    printf("\nFile Name\tInode Number\tFile Size\tLink Count\n");
    printf("-----------------------------------------------------------------------------\n");
    while(Temp!=NULL)
    {
        if(Temp->FileType!=0)
        {
            printf("%s\t\t%d\t\t%d\t\t%d\n",Temp->FileName,Temp->InodeNumber,Temp->FileActualSize,Temp->LinkCount);
        }
        Temp=Temp->Next;
    }
    printf("-----------------------------------------------------------------------------\n");

}
void DisplayHelp()
{
    printf("\nls:To list out all files\n");
    printf("cls:To clear console\n");
    printf("open:To open the file\n");
    printf("close:To close the file\n");
    printf("closeall:To close all opened files\n");
    printf("read:To Read contents from the file\n");
    printf("write:To Write the contents into the file\n");
    printf("exit:To Terminate the file system\n");
    printf("stat:To Display information of the file using file name\n");
    printf("fstat:To Display information of the file using file descriptor\n");
    printf("truncate:To Remove all data from file\n");
    printf("rm:To Delete the file\n");
}

void man(char*name)
{
    if(name==NULL)
    {
        return;
    }
    if(strcmp(name,"create")==0)
    {
        printf("Description:Used to create new Regular file.\n");
        printf("Usage:create File_name Permission\n");
    }
    else if(strcmp(name,"read")==0)
    {
        printf("Description:Used to Read data from Regular file.\n");
        printf("Usage:read File_name No_of_Bytes_To_Read\n");
    }
    else if(strcmp(name,"write")==0)
    {
        printf("Description:Used to Write into Regular file.\n");
        printf("Usage:write File_name\nAfter this enter the data that we want to Write\n");
    }
    else if(strcmp(name,"ls")==0)
    {
        printf("Description:Used to list all information of files.\n");
        printf("Usage:ls\n");
    }
    else if(strcmp(name,"stat")==0)
    {
        printf("Description:Used to Display information of the file.\n");
        printf("Usage:stat File_name\n");
    }
    else if(strcmp(name,"fstat")==0)
    {
        printf("Description:Used to Display information of the file.\n");
        printf("Usage:stat File_Descriptor\n");
    }
    else if(strcmp(name,"truncate")==0)
    {
        printf("Description:Used to Remove Data from the file.\n");
        printf("Usage:truncate File_name\n");
    }
    else if(strcmp(name,"open")==0)
    {
        printf("Description:Used to open existing file.\n");
        printf("Usage:open File_name Mode\n");
    }
    else if(strcmp(name,"close")==0)
    {
        printf("Description:Used to close opened file.\n");
        printf("Usage:close File_name\n");
    }
    else if(strcmp(name,"closeall")==0)
    {
        printf("Description:Used to close all opened file.\n");
        printf("Usage:closeall\n");
    }
    else if(strcmp(name,"lseek")==0)
    {
        printf("Description:Used to change the file offset.\n");
        printf("Usage:lseek File_name ChangeInOffset StartPoint\n");
    }
    else if(strcmp(name,"rm")==0)
    {
        printf("Description:Used to Delete the File.\n");
        printf("Usage:rm File_Name\n");
    }
    else
    {
        printf("ERROR:No manual entry available.\n");
    }
}
int main()
{
    char*ptr=NULL;
    char str[80]={"\0"};
    char command[4][80];
    char arr[1024];
    int count=0;
    int iRet=0;
    int fd=0,ret=0;
    
    SetEnvironment();
    
    while(1)
    {
        fflush(stdin);
        strcpy(str,"");
        printf("\nCustomised VFS:> ");
        fgets(str,80,stdin);
        count=sscanf(str,"%s%s%s%s",command[0],command[1],command[2],command[3]);
        if(count==1)
        {
            if(strcmp(command[0],"ls")==0)
            {
                ls();
            }
            else if(strcmp(command[0],"help")==0)
            {
                DisplayHelp();
                continue;
            }
            else if(strcmp(command[0],"cls")==0)
            {
                system("cls");
                continue;
            }
            else if(strcmp(command[0],"exit")==0)
            {
                printf("Terminating The Customised Virtual File System.");
                break;
            }
            else
            {
                printf("\nERROR:Command Not Found!!!\n");
                continue;
            }
            
        }
        else if(count==2)
        {
            if(strcmp(command[0],"man")==0)
            {
                man(command[1]);
                continue;
            }
            else if(strcmp(command[0],"write")==0)
            {
                fd=GetFdFromName(command[1]);
                if(fd==-1)
                {
                    printf("name does not exist");
                    continue;
                }
                printf("Enter the data to Write.\n");
                scanf(" %[^'\n']s",arr);
                ret=strlen(arr);
                iRet=Write_File(fd,arr,ret);
                if(iRet>=0)
                {
                    printf("Data written Successfully.\n");
                }
                else
                {
                    printf("ERROR");
                }
                continue;
            }
            else
            {
                printf("\nERROR:Command Not Found!!!\n");
                continue;
            }
            
        }
        else if(count==3)
        {
            if(strcmp(command[0],"create")==0)
            {
                iRet=CreateFile(command[1],atoi(command[2]));

                if(iRet>=0)
                    printf("File Successfully Created with file Descriptor %d.\n",iRet);
                if(iRet==-1)
                    printf("ERROR:Incorrect Parameter.\n");
                if(iRet==-2)
                    printf("ERROR:There is NO Inode.\n");
                if(iRet==-3)
                    printf("ERROR:File Already Exists.\n");
                if(iRet==-4)
                    printf("ERROR:There is No Enough Memory.\n");
                    
                continue;
            }
            else if(strcmp(command[0],"open")==0)
            {
                iRet=Open_File(command[1],atoi(command[2]));
                if(iRet>=0)
                    printf("File is successfully open with file descriptor %d.\n",iRet);
                if(iRet==-1)
                    printf("ERROR:Incorrect Parameters.\n");
                if(iRet==-2)
                    printf("ERROR:File Not Present.\n");
                if(iRet==-3)
                    printf("ERROR:Permission Denied.\n");
                continue;
            }
            else
            {
                printf("\nERROR:Command Not Found!!!\n");
                continue;
            }
            
        }
        else if(count==4)
        {

        }
        else
        {
            printf("\nERROR:Command Not Found!!!\n");
            continue;
        }
    }
}