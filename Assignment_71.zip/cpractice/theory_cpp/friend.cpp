#include<iostream>
using namespace std;
class base
{
    int i;
    void fun();
    public:
    base()
    {
        i=63;
    }
    friend void sun();
    friend void derived::gun();
};

void base:: fun()
{
    cout<<"in fun\n";
    i=640;
    cout<<i;
}

class derived:public base
{
    int j;
    public:
    void gun();
};

void derived::gun()
{
    j=9999;
}

void sun()   //nacked function
{
    base obj1;
    cout<<obj1.i<<endl;
    //cout<<obj1.fun<<endl;

}
int main()
{
    sun();
    return 0;
}
