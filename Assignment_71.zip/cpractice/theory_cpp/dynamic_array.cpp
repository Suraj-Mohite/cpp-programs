using namespace std;
#include<iostream>

void one_dimension()
{
    int i,size,total=0;
    cout<<"Enter the size of array"<<endl;
    cin>>size;
    cout<<"Enter the "<<size<<" elements to add"<<endl;
    int*p=new int[size];
    for(i=0;i<size;i++)
    {
        cin>>p[i];
        total=total+p[i];
    }
    cout<<"Entered "<<size<<"elements to add are"<<endl;
    for(i=0;i<size;i++)
    {
        cout<<p[i]<<"\t";
    }
    cout<<"Total is "<<total<<endl;
    delete[]p;

}

void two_dimension()
{
    int row,col,i,j;
    cout<<"Enter the number of rows"<<endl;
    cin>>row;
    cout<<"Enter the number of columns"<<endl;
    cin>>col;

    int**p;
    p=new int*[row];
    for(i=0;i<row;i++)
    {
        p[i]=new int[col];
    }

    cout<<"Enter the elements for first matrix:"<<endl;

    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            cin>>p[i][j];
        }
    }

    int**ptr;
    ptr=new int*[row];
    for(i=0;i<row;i++)
    {
        ptr[i]=new int[col];
    }

    cout<<"Enter the elements for second matrix:"<<endl;

    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            cin>>ptr[i][j];
        }
    }

    cout<<"first matrix A:"<<endl;

    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            cout<<p[i][j]<<"\t";
        }
        cout<<"\n";
    }

    cout<<"Second matrix B:"<<endl;

    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            cout<<ptr[i][j]<<"\t";
        }
        cout<<"\n";
    }

    int**sum=new int*[row];
    for(i=0;i<row;i++)
    {
        sum[i]=new int[col];
    }

    cout<<"Addition of two matrix A and B is:"<<endl;

    for(i=0;i<row;i++)
    {
        for ( j = 0; j<col;j++)
        {
            sum[i][j]=p[i][j]+ptr[i][j];
        }
    }
    for(i=0;i<row;i++)
    {
        for ( j = 0; j<col;j++)
        {
            cout<<sum[i][j]<<"\t";
        }
        cout<<"\n";
    }

//deallocation of memory
    for(i=0;i<row;i++)
    {
        delete[]p[i];
    }
    delete[]p;
    //dealocation for matrix B
    for(i=0;i<row;i++)
    {
        delete[]ptr[i];
    }
    delete[]ptr;
    //for sum
    for(i=0;i<row;i++)
    {
        delete[]sum[i];
    }
    delete[]sum;
}

void three_dimension()
{
    int size_x,size_y,size_z,i,j,k,***p;

    cout<<"Enter size of first Dimension elements (x-axis) :"<<endl;
    cin>>size_x;
    cout<<"Enter size of second dimension elements (y-axis) :"<<endl;
    cin>>size_y;
    cout<<"Enter size of third dimension elements (z-axis) :"<<endl;
    cin>>size_z;
    
    p=new int**[size_x];
    for(i=0;i<size_x;i++)
    {
        p[i]=new int*[size_y];
        for(j=0;j<size_y;j++)
        {
            p[i][j]=new int[size_z];
        }
    }

    cout<<"Enter three dimensional elements of matrix A:"<<endl;
    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            for(k=0;k<size_z;k++)
            {
                cin>>p[i][j][k];
            }
        }
    }

    int***p1;
    p1=new int**[size_x];
    for(i=0;i<size_x;i++)
    {
        p1[i]=new int*[size_y];
        for(j=0;j<size_y;j++)
        {
            p1[i][j]=new int[size_z];
        }
    }

    cout<<"Enter three dimensional elements of matrix B:"<<endl;
    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            for(k=0;k<size_z;k++)
            {
                cin>>p1[i][j][k];
            }
        }
    }

    int*** sum=new int**[size_x];
    for(i=0;i<size_x;i++)
    {
        sum[i]=new int*[size_y];
        for(j=0;j<size_y;j++)
        {
            sum[i][j]=new int[size_z];
        }
    }

    cout<<"matrix A:"<<endl;
    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            for(k=0;k<size_z;k++)
            {
                cout<<p[i][j][k]<<"\t";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }

    cout<<"matrix B:"<<endl;
    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            for(k=0;k<size_z;k++)
            {
                cout<<p1[i][j][k]<<"\t";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }

    cout<<"Addition of matrix A and B is:"<<endl;
    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            for(k=0;k<size_z;k++)
            {
                sum[i][j][k]=p[i][j][k]+p1[i][j][k];
                cout<<sum[i][j][k]<<"\t";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }

    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_y;j++)
        {
            delete[]p[i][j];
        }
        delete[]p[i];
    }
    delete[]p;

    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_x;j++)
        {
            delete[]p1[i][j];
        }
        delete[]p1[i];
    }
    delete[]p1;

    for(i=0;i<size_x;i++)
    {
        for(j=0;j<size_x;j++)
        {
            delete[]sum[i][j];
        }
        delete[]sum[i];
    }
    delete[]sum;
}

void four_dimension()
{
    int first,second,third,fourth,i,j,k,l;
    cout<<"Enter size of first Dimension elements (first) :"<<endl;
    cin>>first;
    cout<<"Enter size of second dimension elements (second) :"<<endl;
    cin>>second;
    cout<<"Enter size of third dimension elements (third) :"<<endl;
    cin>>third;
    cout<<"Enter size of third dimension elements (fourth) :"<<endl;
    cin>>fourth;

    int****p=new int***[first];
    for(i=0;i<first;i++)
    {
        p[i]=new int**[second];
        for(j=0;j<second;j++)
        {
            p[i][j]=new int*[third];
            for(k=0;k<third;k++)
            {
                p[i][j][k]=new int[fourth];
            }
        }
    }

    cout<<"Enter element for matrix A:"<<endl;
    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                for(l=0;l<fourth;l++)
                {
                    cin>>p[i][j][k][l];
                }
            }
        }
    }

    int****p1=new int***[first];
    for(i=0;i<first;i++)
    {
        p1[i]=new int**[second];
        for(j=0;j<second;j++)
        {
            p1[i][j]=new int*[third];
            for(k=0;k<third;k++)
            {
                p1[i][j][k]=new int[fourth];
            }
        }
    }

    cout<<"Enter element for matrix B:"<<endl;
    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                for(l=0;l<fourth;l++)
                {
                    cin>>p1[i][j][k][l];
                }
            }
        }
    }

    cout<<"matrix A:"<<endl;
    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                for(l=0;l<fourth;l++)
                {
                    cout<<p[i][j][k][l]<<"\t";
                }
                cout<<"\n";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }

    cout<<"matrix B:"<<endl;
    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                for(l=0;l<fourth;l++)
                {
                    cout<<p1[i][j][k][l]<<"\t";
                }
                cout<<"\n";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }
    int****sum=new int***[first];
    for(i=0;i<first;i++)
    {
        sum[i]=new int**[second];
        for(j=0;j<second;j++)
        {
            sum[i][j]=new int*[third];
            for(k=0;k<third;k++)
            {
                sum[i][j][k]=new int[fourth];
            }
        }
    } 

    cout<<"sum of A and B is:"<<endl;
    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                for(l=0;l<fourth;l++)
                {
                    sum[i][j][k][l]=p[i][j][k][l]+p1[i][j][k][l];
                    cout<<sum[i][j][k][l]<<"\t";
                }
                cout<<"\n";
            }
            cout<<"\n";
        }
        cout<<"\n";
    }

    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                delete[]p[i][j][k];
            }
            delete[]p[i][j];
        }
        delete[]p[i];
    }
    delete[]p;

    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                delete[]p1[i][j][k];
            }
            delete[]p1[i][j];
        }
        delete[]p1[i];
    }
    delete[]p1;

    for(i=0;i<first;i++)
    {
        for(j=0;j<second;j++)
        {
            for(k=0;k<third;k++)
            {
                delete[]sum[i][j][k];
            }
            delete[]sum[i][j];
        }
        delete[]sum[i];
    }
    delete[]sum;

}
int main()
{
    int no;
    cout<<"press:\n1:for addition of element of 1D array.\n2:for addition of 2D matix.\n3:for addition of 3D maatrix.\n4:for addition of 4D maatrix"<<endl;
   
    while(1)
    {
        cin>>no;
        switch(no)
          {
             case 1:
               one_dimension();
               break;
             case 2:
               two_dimension();
               break;
             case 3:
               three_dimension();
               break;
             case 4:
               four_dimension();
               break;
             default:
               cout<<"Please choose correct option"<<endl;
               continue;
           }
    }
    
    return 0;
}