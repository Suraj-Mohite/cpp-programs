#include<iostream>
using namespace std;

class base
{
    private:
       //const int k;
    public:
        int i;
        const int j;  //const characteristics
        static int l;
        base(int a=10,int b=55,int c=0):j(b)
        {
            i=a;
           // cout<<k<<endl;
        }
        void fun()const
        {
            //i=987;
            l=47;
            //i++;    NA

        }
        void gun(int no1,const int no2)
        {
            cout<<"in gun\n";
            i+=5000;
           // j++;
            cout<<"spm"<<no1<<endl<<no2<<endl;
        }
};
 int base::l=601;

class derived:public base
{
    public:
    void fun()
    {
        l=63;
    }
};

int main()
{
    base obj1;
    derived dobj;
    const base obj;
    //obj.i=6;   if we make any object constant then all characteristics of that object become const
    cout<<obj.i<<endl;
    cout<<obj.j<<endl;
    //cout<<obj.k<<endl;
    cout<<base::l<<endl;
   // obj.gun(); const obj only calls const function
    obj.fun();
    obj1.fun();
    obj1.gun(11,22);
    cout<<obj.i<<endl;
    cout<<obj.l<<endl;
    //bp=&dobj;
    dobj.fun();
    cout<<dobj.l;
    return 0;
}