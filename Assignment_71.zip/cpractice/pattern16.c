#include<stdio.h>
int main()
{
    int i,j;
    for(i=1;i<=7;i++)
    {
        for(j=0;j<=7;j++)
        {
            if(i<5)
            {
                if(j<=i-1||(j>=i+1&&j<=7-i)||j>=9-i)
                {
                    printf("*");
                }
                else
                {
                    if(i<=3&&i==j)
                    {
                        printf("\\");

                    }
                    else
                    {
                        printf("/");
                    }
                }
            }
            if(i>=5)
            {
                if(j<=7-i||(j>=9-i&&j<=i-1)||j>=i+1)
                {
                    printf("*");
                }
                else
                {
                    j==8-i?printf("/"):printf("\\");
                }
                
            }
                
            
        }
        printf("\n");
    }
    return 0;
}