#include<stdio.h>
int gun(void);
void sun(int);
int main()
{
    int z=0;
    int fun (void);
    z=fun();
     if (z=4)
     {
         printf("you have entered invalid passward 3 times\n");
         printf("your card is blocked,Please contact your bank\n");
     }
     printf("Thanks for using SBI ATM\n");
     return 0;
}
int fun()
{
    int k=0;
    int x=1;
     for(x=1;x<=3;x++)
     {
         printf("Please Enter 4 digit password\n");
         scanf("%d",&k);
         sun(k);
     }
     return(x);
}
void sun(int d)
{
    int b=0,q=0;
    if (d==3942)
      {
        printf("To check balance press 0:\n");
        printf("To check account number press 1:\n");
        b=gun();
         if(b=4)
          { 
             printf("you have exhausted time limit\n");
             printf("Please Re-enter your card\n");
          }
      }
    else
     {
        printf("Please Enter Correct Password\n");
     }  

    
}

int gun()
{
    int no=0;
    int i=1;
    for(i=1;i<=3;i++)
     {
         printf("choose option");
         scanf("%d",&no);
           if(no==0)
            {
              printf("your balance is 50,000 /- rupees only\n"); 
              break;  
            }
           if(no==1)
            {
                printf("your account number is SBB40266398001\n");
                break;
            }
           if(no>1)
            {
              printf("choose correct option\n");
            }
     }
      return(i);
     
}