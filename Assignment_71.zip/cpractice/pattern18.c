#include<stdio.h>
int main()
{
    int i,j,k;

    for(i=1;i<=9;i++)
    {
        k=1;
        for(j=1;j<=5;j++)
        {
            if(j>=6-i&&j>=i-4)
            {
                printf("%d",k);
                k++;
            }
            else
            {
                printf(" ");
            }   

        }
        printf("\n");
    }
}



/*
#include<stdio.h>
int main()
{
    int i,j,k;

    for(i=1;i<=9;i++)
    {
        k=1;
        if (i<6)
        {
           for(j=1;j<=5;j++)
             {
                if(j>=6-i)
                 {
                    printf("%d",k);
                    k++;
                 }
                else
                 {
                   printf(" ");
                 }   

             }
               printf("\n");
        }
        else
        {
            for(j=1;j<=5;j++)
             {
                if(j>=i-4)
                 {
                    printf("%d",k);
                    k++;
                 }
                else
                 {
                   printf(" ");
                 }   

             }
               printf("\n");
        }
        
    }
}
*/