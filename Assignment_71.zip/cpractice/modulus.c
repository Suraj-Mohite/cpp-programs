#include<stdio.h>
int main()
{
    int x=0,y=0;
   // x=6%3;
    printf("enter number\n x= ");
    scanf("%d",&x);
    printf("\n y= ");
    scanf("%d",&y);

    if(x%y!=0)
     {
         printf("numbers are not  divisible");
     }
     else
     {
         printf("numbers are divisible");
     }
    return 0;
}