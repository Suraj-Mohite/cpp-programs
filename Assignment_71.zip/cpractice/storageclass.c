                   //example of auto, register and static local storage class and extern + global staticclass
#include<stdio.h> //from filestorageclass1.c

    extern int s;       //extern used to import variable from another file
   // extern p;
    extern static u;
    extern int gun1();   //declaration
int main()
{
    printf("inside main...\n");
    function();
    printf("End of the Function..\n");
    gun();
    gun();
    gun();
    gun();
    printf("end of the gun\n");
    printf("inside main for extern\n");

    printf("%d\n",s);
   // printf("%d\n",p);
    printf("%d\n",u);
     gun1();
    return 0;
}
int function()       //defination means no ; mark 
{
int i;
int j=100;
auto int k;
auto int l=60;
register m;
register n=301;
printf("%d\n%d\n%d\n%d\n%d\n%d\n",i,j,k,l,m,n);

}
int gun()
{
    printf("inside static gun function / block\n");
    int x=100;
    auto int x1=200;
    static int y=300;
    x++;
    x1++;
    y++;
    printf("%d\n%d\n%d\n",x,x1,y);
}