#include<stdio.h>
int main()
{
    float a=0;
    float pcircle(void);
    a=pcircle();
    printf("perimeter of circle is= %d",a);
    return 0;
}
 float pcircle()
 {
     float r=0,p=0;
     printf("enter radius of circle in meter ");
     scanf("%f",&r);
     p=2*3.14*r;
     return(p);

 }