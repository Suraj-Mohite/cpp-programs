#include<stdio.h>
struct book
{
    int id;
    char title[20];
    float price;
};
struct book input()
{
    struct book b;
    printf("enter id,title and price");
    scanf("%d",&b.id);
    fflush(stdin); 
    gets(b.title);
    scanf("%f",&b.price);
    return(b);
}
void display(struct book b)
{
    printf("\n %d %s %f",b.id,b.title,b.price);
}
void main()
{
    struct book b1;
    b1=input();
    display(b1);


}