#include<stdio.h>
int s=10;
//register p=20;
static int u=30;

int gun1()
{
    printf("inside gun1 extern gun function from another file");

}
