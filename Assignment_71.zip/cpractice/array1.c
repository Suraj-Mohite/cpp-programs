#include<stdio.h>
int main()
{
   int number[10],i,sum=0,sum1=0;
   float avg,k=0.0,k1=0.0;
   printf("enter 10 number:\n");
   for(i=0;i<=9;i++)
   {
       scanf("%d",&number[i]);
   }

   for(i=0;i<=9;i++)
   {
       if(number[i]%2==0)
         {
             k++;
             sum=sum+number[i];
         }
       if(number[i] & 1==1)
        {
            k1++;
            sum1=sum1+number[i];
        }
   }

      avg=sum/k;
      
     printf("total even number:%f and odd number:%f\n",k,k1);
   printf("sum of entered even number is:%d\nAverage of entered even number is:%f",sum,avg);

      avg=sum1/k1;

   printf("sum of entered odd number is:%d\nAverage of entered odd number is:%f",sum1,avg);

   // printf("\naverage is: %f",avg);
   return 0;
}