#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void sort(int*,int);
void decrease(int*,int);

int main()
{
   int i,n,*ptr=NULL;

   printf("Enter number of array\n");
   scanf("%d",&n);

   ptr=(int*)calloc(n,sizeof(int));

    printf("enter %d no.\n",n);
    for(i=0;i<=n-1;i++)
     {
        scanf("%d",ptr+i);
     }
    printf("\n");
    sort(ptr,n);
    for(i=0;i<=n-1;i++)
     {
        printf("%d ",*(ptr+i));
     }
     printf("\n");
     decrease(ptr,n);
     for(i=0;i<=n-1;i++)
     {
        printf("%d ",*(ptr+i));
     }
     free(ptr);
    return 0;
}
void sort(int*p,int b)
{
    int i,round,temp;
    for(round=1;round<=b-1;round++)
     {
        for(i=0;i<=b-1-round;i++)
         {
            if(*(p+i)>*(p+i+1))       //a[i]=*(p+i)
             {
                temp=*(p+i);
                *(p+i)=*(p+i+1);
                *(p+i+1)=temp;
             }
         }
     }
}

void decrease(int*p,int b)
{
   int round,i,temp;
   for(round=1;round<=b-1;round++)
   {
       for(i=0;i<=b-1-round;i++)
       {
          if(*(p+i)<*(p+i+1))
          {
              temp=*(p+i);
              *(p+i)=*(p+i+1);
              *(p+i+1)=temp;
          }
       }
   }
}