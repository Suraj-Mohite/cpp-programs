//recursion program
#include<stdio.h>
int fun(int);
int main()
{
    int i,number=0;
    printf("enter the number: ");
    scanf("%d",&number);
    i=fun(number);
    printf("Addition of first %d number is %d",number,i);
    return 0;
}
int fun(int a)
{
  int s;
  if(a==1)
  {
  return(a);
  }
  s=a+fun(a-1);
  return(s);
}