#include<stdio.h>
void ascend(int [],int);
void descend(int [],int);
int main()
{
    int i,a[15];
    
    printf("Enter random 15 number: ");
    for(i=0;i<=14;i++)
    {
        scanf("%d",&a[i]);
    }
    for (i=0;i<=14;i++)
    {
        printf("%d ",a[i]);
    }

    descend(a,15);
    printf("\n");
    printf("Entered number in descending order is :");
    for (i=0;i<=14;i++)
    {
        printf("%d ",a[i]);
    }

    ascend(a,15);
    printf("\n");
    printf("Entered number in ascending order is :");
    for(i=0;i<=14;i++)
    {
       printf("%d ",a[i]);
    } 
    return 0;
}
void descend(int p[],int b)
{
    int round,i,temp;
    for(round=1;round<=14;round++)
    {
        for(i=0;i<=b-1-round;i++)
        {
            if (p[i]<p[i+1])
            {
                temp=p[i+1];
                p[i+1]=p[i];
                p[i]=temp;
            }
        }
    }
}

void ascend(int a[],int b)
{
    int i,pass,temp;
    for(pass=1;pass<=14;pass++)
    {
        for(i=0;i<=b-1-pass;i++)
        {
            if(a[i]>a[i+1])
            {
                temp=a[i];
                a[i]=a[i+1];
                a[i+1]=temp;
            }
        }
    }
}