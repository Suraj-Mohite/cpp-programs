//urinary opertor + - ++ -- sizeof()
#include<stdio.h>
int main()
{
  //  clrscr();
    int x=5;
    int s[5]={60,3,5,3};
    int p,y,z=0;
    float f=0.0;
    double d=52.69;
    char c='a';
   // x=x+s;
   // y=20>26<6>963;
   // p=20|30;
   // z=~12;  
   printf("%d\n\n",s);
   printf("%d\n\n",&s);
   printf("%d\n\n",s+1);
   printf("%d\n\n",&s+1);
   printf("%d\n\n",s[3]);
   printf("%d\n\n",s[3+1]);
   printf("%d\n\n",s[3]+1);
   printf("%d\n\n",s[4]);

    //--x;
   // printf("%d\n",x);

   printf("%d\n",sizeof(s));
   printf("%d\n",sizeof(0.0f));
   printf("%d\n",sizeof(52.69));
   printf("%d\n",sizeof("a"));    //ans is 2 byte
   printf("%d\n",sizeof('a'));    // ans is 4 byte 
   printf("%d\n",sizeof(short int));

    y= x++;
    printf("%d%d\n\t",x,y);
    z= ++x;
    printf("%d%d",x,z);
    //printf("");
    //printf("");
    return 0;
}