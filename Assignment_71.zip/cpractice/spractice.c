//structure and function take nothing return nothing 
#include<stdio.h>
struct demo
{
    int i;
    int d,m,y;
    float j;
    char ch;
    //double k;
}d2;

void fun()
{
    printf("ente your birth date\n");
    scanf("%d%d%d",&d2.d,&d2.m,&d2.y);
    printf("Your birthday is :%d/%d/%d\n",d2.d,d2.m,d2.y);
}

int main()
{
    void fun();
    // struct demo d1={50,12.6,"d"};
     //printf("%d\n",d1);
    //printf("%d\n",sizeof(struct demo));
    //printf("%d\n",d1.i);
    //printf("%c\n",d1.ch);
    fun();
    
    return 0;
}



