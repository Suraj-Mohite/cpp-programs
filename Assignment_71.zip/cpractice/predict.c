#include<stdio.h>
int main()
{ 
    int i=10, j=20;
    j=j||i++ && printf("hello");
    printf("%d\n%d\n%d",j||j,i&=j,(2,3,1,4));
    return 0;
}