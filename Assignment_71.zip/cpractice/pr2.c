#include<stdio.h>

int main()
{
    int a=10;
    int b=63;
    int c=0;
    c=a+b;
    printf("additio of a+b = %d\n",c);

    return 0;

}