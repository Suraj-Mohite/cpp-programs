#include<stdio.h>
#include<string.h>
int main()
{
    char brr[30];
    int arr[10];
    arr[0]=98;
    arr[6]=67;
    arr[2+3]=74;
    printf("%d\n",arr);
    printf("%d\n",arr[0]+arr[3+3]);
    printf("%d\n",arr[5]+1);
    printf("%d\n",&(arr[5]));
    printf("%d\n",arr+1);
    printf("%d\n",&arr+1);
    printf("name\n");
    //gets(brr);
    strcpy(brr,"suraj prakash mohite");
    printf(brr);



    return 0;
}