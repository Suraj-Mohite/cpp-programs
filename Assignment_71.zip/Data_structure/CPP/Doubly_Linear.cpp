#include<iostream>
using namespace std;


typedef class Node
{
    public:
    int Data;
    Node* Next;
    Node* Prev;

    Node(int No)
    {
        Data=No;
        Next=NULL;
        Prev=NULL;
    }

}NODE,*PNODE;

class DoublyLL
{
    private:
        int size;
        PNODE Head;
    public:
        DoublyLL();
        void InsertFirst(int);
        void InsertLast(int);
        void DeleteFirst();
        void DeleteLast();
        void InsertAtPos(int,int);
        void DeleteAtPos(int);
        void Display();
        int Count();
};

DoublyLL::DoublyLL()
{
    Head=NULL;
    size=0;
}

void DoublyLL::InsertFirst(int No)
{
    PNODE Newn=new NODE(No);
    
    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        Newn->Next=Head;
        Head->Prev=Newn;
        Head=Newn;
    }
    size++;
}

void DoublyLL::InsertLast(int No)
{
    PNODE Newn=new NODE(No);
    
    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        PNODE Temp=Head;
        while((Temp->Next)!=NULL)
        {
            Temp=Temp->Next;
        }
        (Newn->Prev)=Temp;
        (Temp->Next)=Newn;
    }
    size++;
}
void DoublyLL::DeleteFirst()
{
    if(Head==NULL)
    {
        return;
    }
    else
    {
        if(Head->Next==NULL)
        {
            delete Head;
            Head=NULL;
        }
        else
        {
            Head=Head->Next;
            delete Head->Prev;
            Head->Prev=NULL;
        }
        
    }
    
    size--;
}
void DoublyLL::DeleteLast()
{
    if(Head==NULL)
    {
        return;
    }
    if(Head->Next==NULL)
    {
        delete Head;
        Head=NULL;
    }
    else
    {
        PNODE Temp=Head;
        while(Temp->Next!=NULL)
        {
            Temp=Temp->Next;
        }
        Temp->Prev->Next=NULL;
        delete Temp;
    }
    size--;
    
}

void DoublyLL::Display()
{
    PNODE Temp=Head;
    while(Temp!=NULL)
    {
        cout<<"|"<<Temp->Data<<"|<->";
        Temp=Temp->Next;
    }
    cout<<"\n";
}
int DoublyLL::Count()
{
    return size;
}
void DoublyLL::InsertAtPos(int No,int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize+1))
    {
        return;
    }
    if(Pos==1)
    {
        InsertFirst(No);
    }
    else if(Pos==iSize+1)
    {
        InsertLast(No);
    }
    else
    {
        PNODE Newn=new NODE(No);
        PNODE Temp=Head;
        for(int i=1;i<(Pos-1);i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next->Prev=Newn;
        Newn->Prev=Temp;
        Temp->Next=Newn;
        size++;
    }
}
void DoublyLL::DeleteAtPos(int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize))
    {
        return;
    }
    if(Pos==1)
    {
        DeleteLast();
    }
    else if(Pos==iSize)
    {
        DeleteLast();
    }
    else
    {
        PNODE Temp=Head;
        for(int i=1;i<(Pos-1);i++)
        {
            Temp=Temp->Next;
        }
        Temp->Next=Temp->Next->Next;
        delete Temp->Next->Prev;
        Temp->Next->Prev=Temp;
        size--;
    }
}

int main()
{
    DoublyLL obj;
    int iChoice=1,iPos=0,No=0,iCnt=0;

    while(iChoice!=0)
    {
        cout<<"\n------------------------------------------------------------------------------------------------\n";
        cout<<"Enter:\n";
        cout<<"1:Insert First"<<endl;
        cout<<"2:Insert Last"<<endl;
        cout<<"3:Insert At Position"<<endl;
        cout<<"4:Delete First"<<endl;
        cout<<"5:Delete Last"<<endl;
        cout<<"6:Delete At Position"<<endl;
        cout<<"7:Display"<<endl;
        cout<<"8:Count"<<endl;
        cout<<"0:Exit"<<endl;
        cout<<"------------------------------------------------------------------------------------------------\n";
        cout<<"Select option.\n";
        cin>>iChoice;
        cout<<"------------------------------------------------------------------------------------------------\n";
        
        switch(iChoice)
        {
            case 1:
                cout<<"Enter the element to insert at first position"<<endl;
                cin>>No;
                obj.InsertFirst(No);
                break;
            case 2:
                cout<<"Enter the element to insert at Last position"<<endl;
                cin>>No;
                obj.InsertLast(No);
                break;
            case 3:
                cout<<"Enter the element to insert at Nth position"<<endl;
                cin>>No;
                cout<<"Enter the position"<<endl;
                cin>>iPos;
                obj.InsertAtPos(No,iPos);
                break;
            case 4:
                obj.DeleteFirst();
                break;
            case 5:
                obj.DeleteLast();
                break;
            case 6:
                cout<<"Enter the position"<<endl;
                cin>>iPos;
                obj.DeleteAtPos(iPos);
                break;
            case 7:
                cout<<"Elements of your linked list are:\n";
                obj.Display();
                break;
            case 8:
                iCnt=obj.Count();
                cout<<"Number of elements in your linked list are: "<<iCnt<<"\n";
                break;
            case 0:
                break;
            default:
                cout<<"Wrong Choice....\n";
        }
    }
    cout<<"Thank You For Using Application"<<endl;
    return 0;
}
