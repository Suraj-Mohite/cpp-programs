using namespace std;
#include<iostream>

typedef class Node
{
    public:
    int Data;
    Node*Next;
}NODE,*PNODE;

class SinglyLL
{
    private:
    int size;
    PNODE Head;
    PNODE Newn;

    public:

    SinglyLL();
    void InsertFirst(int);
    void InsertLast(int);
    void InsertAtPos(int,int);
    void Display();
    int Count();
    void DeleteFirst();
    void DeleteLast();
    void DeleteAtPos(int);

};


SinglyLL::SinglyLL()
{
    Head=NULL;
    size=0;
}

void SinglyLL::InsertFirst(int No)
{
    Newn = new NODE;
    Newn->Next=NULL;
    Newn->Data=No;
    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        Newn->Next=Head;
        Head=Newn;
    }
    size++;
}

void SinglyLL::InsertLast(int No)
{
    Newn = new NODE;
    Newn->Next=NULL;
    Newn->Data=No;    
    
    if(Head==NULL)
    {
        Head=Newn;
    }
    else
    {
        PNODE Temp=Head;
        while(Temp->Next!=NULL)
        {
            Temp=Temp->Next;
        }
        Temp->Next=Newn;
    }
    size++;
}

void SinglyLL::DeleteFirst()
{
    if(Head==NULL)
    {
        return;
    }
    PNODE Temp=Head;
    if(Temp->Next==NULL)
    {
        delete Temp;
        Head=NULL;
    }
    else
    {

        Head=Head->Next;
        delete Temp;

    }
    
    size--;
}

void SinglyLL::DeleteLast()
{
    if(Head==NULL)
    {
        return;
    }
    PNODE Temp=Head;

    if (Temp->Next==NULL)
    {
        delete Temp;
        Head=NULL;
    }
    else
    {
        while(Temp->Next->Next!=NULL)
        {
            Temp=Temp->Next;
        }
        delete Temp->Next;
        Temp->Next=NULL;    
    }
     size--;
}

void SinglyLL::Display()
{
    PNODE Temp=Head;
    if(Head==NULL)
    {
        return;
    }

    while(Temp!=NULL)
    {
        cout<<"|"<<Temp->Data<<"|->";
        Temp=Temp->Next;
    }
    cout<<"NULL";
}

int SinglyLL::Count()
{
    return size;
}

void SinglyLL::InsertAtPos(int No,int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize+1))
    {
        return;
    }
    if(Pos==1)
    {
        InsertFirst(No);
    }
    else if(Pos==iSize+1)
    {
        InsertLast(No);
    }
    else
    {
        PNODE Newn=new NODE;
        Newn->Data=No;
        Newn->Next=NULL;

        PNODE Temp=Head;
        for(int i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next=Newn;

        size++;
    }
}

void SinglyLL::DeleteAtPos(int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize))
    {
        return;
    }
    if(Pos==1)
    {
        DeleteFirst();
    }
    else if(Pos==iSize)
    {
        DeleteLast();
    }
    else
    {
        PNODE Temp=Head;
        PNODE Temp2=NULL;
        for(int i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp2=Temp->Next;
        Temp->Next=Temp2->Next;
        delete Temp2;
        size--;
    }
}

int main()
{
    int Choice=1, Count=0,iPos=0,No=0;
    SinglyLL*obj=new SinglyLL;

    while(Choice!=0)
    {
         cout<<"\n-------------------------------------------------------------------------------------------\n";
         cout<<"Enter:\n1.For insert first.\n2.For Insert last.\n3.For Display Singly linear linked list.\n4.For count members of Singly linear linked list.\n5.For insert at position.\n6.For Delete first.\n7.For delete Last.\n8.For Delete at position.\n0.For Exit\n";
         cout<<"-------------------------------------------------------------------------------------------\n";
         cout<<"Choose the option: \n";
         cin>>Choice;
         cout<<"-------------------------------------------------------------------------------------------\n";

        switch(Choice)
         {
            case 1:
                cout<<"Enter the element to add at first position.\n";
                cin>>No;
                obj->InsertFirst(No);
                break;
            case 2:
                cout<<"Enter the element to add at Last Position.\n";
                cin>>No;
                obj->InsertLast(No);
                break;
            case 3:
                cout<<"Elements of your linked list are.\n";
                obj->Display();
                break;
            case 4:
                Count=obj->Count();
                cout<<"Number of elements in singly linear linked list are:"<<Count<<"\n";
                break;
            case 5:
                cout<<"Enter the element to add in singly linear linked list.\n";
                cin>>No;
                cout<<"Enter the position\n";
                cin>>iPos;
                obj->InsertAtPos(No,iPos);
                break;
            case 6:
                obj->DeleteFirst();
                break;
            case 7:
                obj->DeleteLast();
                break;
            case 8:
                cout<<"Enter the position to Delete element\n";
                cin>>iPos;
                obj->DeleteAtPos(iPos);
                break;
            case 0:
                break;
            default:
                cout<<"Wrong Choice.\n";
                break;
            
         }
    }
    cout<<"Thank You For Using Application.\n";
    delete obj;
    return 0;
}