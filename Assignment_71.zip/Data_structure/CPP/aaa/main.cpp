using namespace std;
#include<iostream>

typedef class Node
{
    public:
    int Data;
    Node* Next;

    Node(int No)
    {
        Data=No;
        Next=NULL;
    }

}NODE,*PNODE;

class SinglyCL
{
    private:
    int size;
    PNODE Head;
    PNODE Tail;
    public:

    SinglyCL();
    void InsertFirst(int);
    void InsertLast(int);
    void InsertAtPos(int,int);
    void Display();
    int Count();
    void DeleteFirst();
    void DeleteLast();
    void DeleteAtPos(int);

};


SinglyCL::SinglyCL()
{
    Head=NULL;
    Tail=NULL;
    size=0;
}

void SinglyCL::InsertFirst(int No)
{
    PNODE Newn = new NODE(No);
    if(Head==NULL)
    {
        Head=Newn;
        Tail=Newn;
    }
    else
    {
        Newn->Next=Head;
        Head=Newn;
    }
    Tail->Next=Head;
    size++;
}

void SinglyCL::InsertLast(int No)
{
    PNODE Newn=new NODE(No);  
    
    if(Head==NULL)
    {
        Head=Newn;
        Tail=Newn;
    }
    else
    {
       Tail->Next=Newn;
       Tail=Newn;
    }
    Tail->Next=Head;
    size++;
}

void SinglyCL::DeleteFirst()
{
    if(Head==NULL)
    {
        return;
    }
    
    if(Head->Next==Head)
    {
        delete Head;
        Head=NULL;
        Tail=NULL;
    }
    else
    {
        Head=Head->Next;
        delete Tail->Next;
        Tail->Next=Head;
    }
    size--;
}

void SinglyCL::DeleteLast()
{
    if(Head==NULL)
    {
        return;
    }
    PNODE Temp=Head;

    if (Temp->Next==Head)
    {
        delete Temp;
        Head=NULL;
        Tail=NULL;
    }
    else
    {
        while(Temp->Next->Next!=Head)
        {
            Temp=Temp->Next;
        }
        delete Temp->Next;
        Tail=Temp;
        Tail->Next=Head;  
    }
     size--;
}

void SinglyCL::Display()
{
    
    if(Head==NULL)
    {
        return;
    }
    PNODE Temp=Head;
    do
    {
        cout<<"|"<<Temp->Data<<"|->";
        Temp=Temp->Next;
    }while(Temp!=Tail->Next);
    cout<<"\n";
}

int SinglyCL::Count()
{
    return size;
}

void SinglyCL::InsertAtPos(int No,int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize+1))
    {
        return;
    }
    if(Pos==1)
    {
        InsertFirst(No);
    }
    else if(Pos==iSize+1)
    {
        InsertLast(No);
    }
    else
    {
        PNODE Newn=new NODE(No);
        PNODE Temp=Head;
        for(int i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next=Newn;

        size++;
    }
}

void SinglyCL::DeleteAtPos(int Pos)
{
    int iSize=Count();
    if((Pos<1)||(Pos>iSize))
    {
        return;
    }
    if(Pos==1)
    {
        DeleteFirst();
    }
    else if(Pos==iSize)
    {
        DeleteLast();
    }
    else
    {
        PNODE Temp=Head;
        PNODE Temp2=NULL;
        for(int i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp2=Temp->Next;
        Temp->Next=Temp2->Next;
        delete Temp2;
        size--;
    }
}

int main()
{
    int Choice=1, Count=0,iPos=0,No=0;
    SinglyCL obj;

    while(Choice!=0)
    {
         cout<<"\n-------------------------------------------------------------------------------------------\n";
         cout<<"Enter:\n1.For insert first.\n2.For Insert last.\n3.For Display Singly Circular linked list.\n4.For count members of Singly Circular linked list.\n5.For insert at position.\n6.For Delete first.\n7.For delete Last.\n8.For Delete at position.\n0.For Exit\n";
         cout<<"-------------------------------------------------------------------------------------------\n";
         cout<<"Choose the option: \n";
         cin>>Choice;
         cout<<"-------------------------------------------------------------------------------------------\n";

        switch(Choice)
         {
            case 1:
                cout<<"Enter the element to add at first position.\n";
                cin>>No;
                obj.InsertFirst(No);
                break;
            case 2:
                cout<<"Enter the element to add at Last Position.\n";
                cin>>No;
                obj.InsertLast(No);
                break;
            case 3:
                cout<<"Elements of your linked list are.\n";
                obj.Display();
                break;
            case 4:
                Count=obj.Count();
                cout<<"Number of elements in singly Circular linked list are:"<<Count<<"\n";
                break;
            case 5:
                cout<<"Enter the element to add in singly Circular linked list.\n";
                cin>>No;
                cout<<"Enter the position\n";
                cin>>iPos;
                obj.InsertAtPos(No,iPos);
                break;
            case 6:
                obj.DeleteFirst();
                break;
            case 7:
                obj.DeleteLast();
                break;
            case 8:
                cout<<"Enter the position to Delete element\n";
                cin>>iPos;
                obj.DeleteAtPos(iPos);
                break;
            case 0:
                break;
            default:
                cout<<"Wrong Choice.\n";
                break;
            
         }
    }
    cout<<"Thank You For Using Application.\n";
    return 0;
}