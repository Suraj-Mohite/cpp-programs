import java.lang.*;
import java.util.*;


class Node
{
	int Data;
	Node Next;
	
	public Node(int Value)
	{
		Data=Value;
		Next=null;
	}
}

class Stack
{
	private Node Head;
	private int iCnt;
	
	public Stack()
	{
		Head=null;
		iCnt=0;
	}
	
	public void Push(int No)
	{
		Node Newn=new Node(No);
		if(Head==null)
		{
			Head=Newn;
		}
		else
		{
			Newn.Next=Head;
			Head=Newn;
		}
		iCnt++;
	}
	
	public int Pop()
	{
		if(Head==null)
		{
			System.out.println("Stack is Empty");
			return -1;
		}
		else
		{
			int Value=Head.Data;
			Head=Head.Next;
			iCnt--;
			return Value;
		}
		
	}
	
	public int Peep()
	{
		if(Head==null)
		{
			System.out.println("Stack is Empty");
			return -1;
		}
		else
		{
			int Value=Head.Data;
			return Value;
		}
	}
	
	public void Display()
	{
		if (Head==null)
		{
			return;
		}
		Node Temp=Head;
		
		while(Temp!=null)
		{
			System.out.println("|"+Temp.Data+"|");
			Temp=Temp.Next;
		}
	}
	public int Count()
	{
		return iCnt;
	}
}

class Demo
{
	public static void main(String []args)
	{
		int iChoice=1;
		Scanner Sobj=new Scanner(System.in);
		Stack obj=new Stack();
		while(iChoice!=0)
		{
			System.out.println("\n--------------------------------------------------------------------------------------");
			System.out.println("Enter: ");
			System.out.println("1: To Push Element.");
			System.out.println("2: To Peep Element.");
			System.out.println("3: To Pop Element.");
			System.out.println("4: To Display All Elements of Stack.");
			System.out.println("5: To Count Element");
			System.out.println("0: To Exit");
			System.out.println("--------------------------------------------------------------------------------------");
			System.out.println("Select Option :");
			iChoice=Sobj.nextInt();
			System.out.println("--------------------------------------------------------------------------------------");
			
			switch(iChoice)
			{
				case 1:
					System.out.println("Enter the element to push into Stack");
					int Value=Sobj.nextInt();
					obj.Push(Value);
				break;
				
				case 2:
					int iPeep=obj.Peep();
					System.out.println("Element is "+iPeep);
				break;
				
				case 3:
					int iPop=obj.Pop();
					System.out.println("Poped Element is "+iPop);			
				break;
				
				case 4:
					obj.Display();
				break;
				
				case 5:
					int iCnt=obj.Count();
					System.out.println("Number of elements are: "+iCnt);
				break;
				
				case 0:
					System.out.println("Thank You For Using Application");
				break;
				
				default:
					System.out.println("ERROR: Wrong Choice");
			}
		}
		
	}
}