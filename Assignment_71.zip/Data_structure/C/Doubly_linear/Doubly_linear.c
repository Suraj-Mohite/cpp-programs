#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
    int Data;
    struct Node* Next;
    struct Node* Prev;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE Head,int iNo)
{
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Prev=NULL;
    Newn->Next=NULL;

    if((*Head)==NULL)
    {
        (*Head)=Newn;
    }
    else
    {
        (*Head)->Prev=Newn;
        Newn->Next=(*Head);
        (*Head)=Newn;
    }
}

void InsertLast(PPNODE Head,int iNo)
{
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Prev=NULL;
    Newn->Next=NULL;

    if((*Head)==NULL)
    {
        (*Head)=Newn;
    }
    else
    {
        PNODE Temp=*Head;
        while(Temp->Next!=NULL)
        {
            Temp=Temp->Next;
        }
        Newn->Prev=Temp;
        Temp->Next=Newn;
    }
}

void DeleteFirst(PPNODE Head)
{
    if((*Head)==NULL)
    {
        return;
    }
    else
    {
        if((*Head)->Next==NULL)
        {
            free(*Head);
            *Head=NULL;
        }
        else
        {
            (*Head)=(*Head)->Next;
            free((*Head)->Prev);
            (*Head)->Prev=NULL;
        }
    }
}
void DeleteLast(PPNODE Head)
{
    if((*Head)==NULL)
    {
        return;
    }
    else
    {
        if((*Head)->Next==NULL)
        {
            free(*Head);
            *Head=NULL;
        }
        else
        {
            PNODE Temp=*Head;
            while(Temp->Next!=NULL)
            {
                Temp=Temp->Next;
            }
            Temp->Prev->Next=NULL;
            free(Temp);
        }
    }
}
int Count(PNODE Head)
{
    int iCnt=0;
    while(Head!=NULL)
    {
        iCnt++;
        Head=Head->Next;
    }
    return iCnt;
}

void InsertAtPos(PPNODE Head,int iNo,int iPos)
{
    int iSize=Count(*Head);
    int i=0;

    if((iPos<1)||(iPos>iSize+1))
    {
        return;
    }

    if(iPos==1)
    {
        InsertFirst(Head,iNo);
    }
    else if(iPos==iSize+1)
    {
        InsertLast(Head,iNo);
    }
    else
    {
         PNODE Newn=NULL;
         Newn=(PNODE)malloc(sizeof(NODE));
         Newn->Data=iNo;
         Newn->Prev=NULL;
         Newn->Next=NULL;

        PNODE Temp=*Head;
        for(i=1;i<iPos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp->Next->Prev=Newn;
        Newn->Next=Temp->Next;
        Newn->Prev=Temp;
        Temp->Next=Newn;
    }
}

void DeleteAtPos(PPNODE Head,int iPos)
{
    int iSize=Count(*Head);
    int i=0;

    if((iPos<1)||(iPos>iSize))
    {
        return;
    }

    if(iPos==1)
    {
        DeleteFirst(Head);
    }
    else if(iPos==iSize)
    {
        DeleteLast(Head);
    }
    else
    {
        PNODE Temp=*Head;
        for(i=1;i<iPos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp->Next=Temp->Next->Next;
        free(Temp->Next->Prev);
        Temp->Next->Prev=Temp;
    }
}

void Display(PNODE Head)
{
    if(Head==NULL)
    {
        return;
    }
    while(Head!=NULL)
    {
        printf("|%d|<->",Head->Data);
        Head=Head->Next;
    }
    printf("NULL\n");
}

int main()
{
    int iChoice=1,iNo=0,iPos=0,iCount=0;
    PNODE First=NULL;

    while(iChoice!=0)
    {
        printf("\n----------------------------------------------------------------------------\n");
        printf("Choose option:\n");
        printf("\t1.Insert First.\n");
        printf("\t2.Insert Last.\n");
        printf("\t3.Delete First.\n");
        printf("\t4.Delete last.\n");
        printf("\t5.Insert At Position.\n");
        printf("\t6.Delete At position.\n");
        printf("\t7.Display Doubly Linear Linked List.\n");
        printf("\t8.Count Elements of Doubly Linear Linked List.\n");
        printf("\t0.Exit\n");
        printf("----------------------------------------------------------------------------\n");
        printf("Enter choice\n");
        scanf("%d",&iChoice);
        printf("----------------------------------------------------------------------------\n");

        switch(iChoice)
        {
            case 1:
                printf("Enter the element to insert at first position.\n");
                scanf("%d",&iNo);
                InsertFirst(&First,iNo);
                break;
            case 2:
                printf("Enter the element to insert at Last position.\n");
                scanf("%d",&iNo);
                InsertLast(&First,iNo);
                break;
            case 3:
                DeleteFirst(&First);
                break;
            case 4:
                DeleteLast(&First);
                break;
            case 5:
                printf("Enter the element to insert at position.\n");
                scanf("%d",&iNo);
                printf("Enter the position.\n");
                scanf("%d",&iPos);
                InsertAtPos(&First,iNo,iPos);
                break;
            case 6:
                printf("Enter the position.\n");
                scanf("%d",&iPos);
                DeleteAtPos(&First,iPos);
                break;
            case 7:
                printf("Elements are:\n");
                Display(First);
                break;
            case 8:
                iCount=Count(First);
                printf("Number of elements of Doubly Linked list are: %d\n",iCount);
                break;
            case 0:
                printf("Thank You For Using Application\n\n");
                break;
            default:
                printf("Wrong Choice: \n");
        }
    }
}