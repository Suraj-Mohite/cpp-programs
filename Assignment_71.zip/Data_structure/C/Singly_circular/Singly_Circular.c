#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
    int Data;
    struct Node* Next;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE Head,PPNODE Tail,int iNo)
{
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Next=NULL;

    if(*Head==NULL)
    {
        *Head=Newn;
        *Tail=Newn;
    }
    else
    {
        Newn->Next=*Head;
        *Head=Newn;
    }
    (*Tail)->Next=*Head;
}
void DeleteFirst(PPNODE Head,PPNODE Tail)
{
    if(*Head==NULL)
    {
        return;
    }
    else
    {
       if((*Head)->Next==(*Head))
       {
           free(*Head);
           *Head=NULL;
           *Tail=NULL;
       }
       else
       {
           *Head=(*Head)->Next;
           free((*Tail)->Next);
           (*Tail)->Next=*Head;
       }
    }
}

void DeleteLast(PPNODE Head,PPNODE Tail)
{
    if(*Head==NULL)
    {
        return;
    }

    if((*Head)->Next==(*Head))
    {
        free(*Tail);
        *Head=NULL;
        *Tail=NULL;
    }
    else
    {
       PNODE Temp=*Head;
       while((Temp->Next->Next)!=*Head)
       {
           Temp=Temp->Next;
       }
       free(*Tail);
       *Tail=Temp;
       (*Tail)->Next=*Head;
    }
}

void InsertLast(PPNODE Head,PPNODE Tail,int iNo)
{
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Next=NULL;

    if(*Head==NULL)
    {
        *Head=Newn;
        *Tail=Newn;
    }
    else
    {
        (*Tail)->Next=Newn;
        *Tail=Newn;
    }
    (*Tail)->Next=*Head;
}

void Display(PNODE Head,PNODE Tail)
{
    if(Head==NULL)
    {
        return;
    }
    if(Head!=NULL)
    {
        do
        {
            printf("|%d|->",Head->Data);
            Head=Head->Next;
        }while(Head!=Tail->Next);
    }
    
}

int Count(PNODE Head,PNODE Tail)
{
    int iCnt=0;
    if (Head==NULL)
    {
        return iCnt;
    }
    do
    {
        iCnt++;
        Head=Head->Next;
    }while(Head!=Tail->Next);

    return iCnt;
}

void InsertAtPos(PPNODE Head,PPNODE Tail,int iNo,int Pos)
{
    int iSize=Count(*Head,*Tail),i=0;
    if(Pos<1||Pos>iSize+1)
    {
        return;
    }
    if(Pos==1)
    {
        InsertFirst(Head,Tail,iNo);
    }
    else if(Pos==(iSize+1))
    {
        InsertLast(Head,Tail,iNo);
    }
    else
    {
        PNODE Newn=NULL;
        Newn=(PNODE)malloc(sizeof(NODE));
        Newn->Next=NULL;
        Newn->Data=iNo;

        PNODE Temp=*Head;
        for(i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next=Newn;
    }
}
void DeleteAtPos(PPNODE Head,PPNODE Tail,int Pos)
{
    int iSize=Count(*Head,*Tail),i=0;
    if(Pos<1||Pos>iSize)
    {
        return;
    }
    if(Pos==1)
    {
        DeleteFirst(Head,Tail);
    }
    else if(Pos==(iSize))
    {
        DeleteLast(Head,Tail);
    }
    else
    {
        PNODE Temp=*Head;
        PNODE Temp2=NULL;
        for(i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp2=Temp->Next;
        Temp->Next=Temp2->Next;
        free(Temp2);
    }
}

int main()
{
    int iChoice=1, iCount=0,iPos=0,iNo=0;
    PNODE First=NULL;
    PNODE Last=NULL;

    while(iChoice!=0)
    {
         printf("\n-------------------------------------------------------------------------------------------\n");
         printf("Enter:\n1.For insert first.\n2.For Insert last.\n3.For Display Singly Circular linked list.\n4.For count members of Singly Circular linked list.\n5.For insert at position.\n6.For Delete first.\n7.For Delete Last.\n8.For Delete at position.\n0.For Exit\n");
         printf("-------------------------------------------------------------------------------------------\n");
         printf("Choose the option: \n");
         scanf("%d",&iChoice);
         printf("-------------------------------------------------------------------------------------------\n");

         switch(iChoice)
         {
            case 1:
                printf("Enter the element to add at first position.\n");
                scanf("%d",&iNo);
                InsertFirst(&First,&Last,iNo);
                break;
            case 2:
                printf("Enter the element to add at Last Position.\n");
                scanf("%d",&iNo);
                InsertLast(&First,&Last,iNo);
                break;
            case 3:
                printf("Elements of your linked list are.\n");
                Display(First,Last);
                break;
            case 4:
                iCount=Count(First,Last);
                printf("Number of elements in singly Circular linked list are: %d\n",iCount);
                break;
            case 5:
                printf("Enter the element to add in singly Circular linked list.\n");
                scanf("%d",&iNo);
                printf("Enter the position\n");
                scanf("%d",&iPos);
                InsertAtPos(&First,&Last,iNo,iPos);
                break;
            case 6:
                DeleteFirst(&First,&Last);
                break;
            case 7:
                DeleteLast(&First,&Last);
                break;
            case 8:
                printf("Enter the position to Delete element\n");
                scanf("%d",&iPos);
                DeleteAtPos(&First,&Last,iPos);
                break;
            case 0:
                break;
            default:
                printf("Wrong Choice.\n");
                break;
            
         }
    }
    printf("Thank You For Using Application.\n");
    return 0;
}