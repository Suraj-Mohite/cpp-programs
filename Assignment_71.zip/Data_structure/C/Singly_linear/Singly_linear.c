#include<stdio.h>
#include<stdlib.h>
/*
struct Node
{
    int Data;
    struct Node* Next;
};

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;*/

typedef struct Node
{
    int Data;
    struct Node* Next;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE Head,int iNo)
{
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Next=NULL;

    if(*Head==NULL)
    {
        *Head=Newn;
    }
    else
    {
        Newn->Next=*Head;
        *Head=Newn;
    }
}

void InsertLast(PPNODE Head,int iNo)
{
    PNODE Temp=*Head;
    PNODE Newn=NULL;
    Newn=(PNODE)malloc(sizeof(NODE));
    Newn->Data=iNo;
    Newn->Next=NULL;

    if(*Head==NULL)
    {
        *Head=Newn;
    }
    else
    {
        while((Temp->Next)!=NULL)
        {
            Temp=Temp->Next;
        }
        Temp->Next=Newn;
    }
}

void DeleteFirst(PPNODE Head)
{
    if(*Head==NULL)
    {
        return;
    }
    else
    {
        if((*Head)->Next==NULL)
        {
            free(*Head);
            (*Head)==NULL;
        }
        else
        {
            PNODE Temp=*Head;
            *Head=(*Head)->Next;
            free(Temp);
        }
    }
}

void DeleteLast(PPNODE Head)
{
    if(*Head==NULL)
    {
        return;
    }
    else
    {
        if((*Head)->Next==NULL)
        {
            free(*Head);
            *Head=NULL;
        }
        else
        {
            PNODE Temp=*Head;
            while((Temp->Next->Next)!=NULL)
            {
                Temp=Temp->Next;
            }
            free(Temp->Next);
            Temp->Next=NULL;
        }
    }
}

int Count(PNODE Head)
{
    int iCnt=0;
    while(Head!=NULL)
    {
        iCnt++;
        Head=Head->Next;
    }
    return iCnt;
}

void InsertAtPos(PPNODE Head,int iNo,int Pos)
{
    int iSize=Count(*Head);
    if((Pos<1)||(Pos>iSize+1))
    {
        return;
    }
    if(Pos==1)
    {
        InsertFirst(&(*Head),iNo);
    }
    else if(Pos==iSize+1)
    {
        InsertLast(&(*Head),iNo);
    }
    else
    {
        PNODE Newn=NULL;
        int i=0;
        Newn=(PNODE)malloc(sizeof(NODE));
        Newn->Data=iNo;
        Newn->Next=NULL;

        PNODE Temp=*Head;
        for(i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Newn->Next=Temp->Next;
        Temp->Next=Newn;
    }
}

void DeleteAtPos(PPNODE Head,int Pos)
{
    int iSize=Count(*Head);
    
    if((Pos<1)||(Pos>iSize))
    {
        return;
    }
    if(Pos==1)
    {
        DeleteFirst(&(*Head));
    }
    else if(Pos==iSize)
    {
        DeleteLast(&(*Head));
    }
    else
    {
        PNODE Temp=*Head;
        PNODE Temp2=*Head;
        int i=0;
        for(i=1;i<Pos-1;i++)
        {
            Temp=Temp->Next;
        }
        Temp2=Temp->Next->Next;
        free(Temp->Next);
        Temp->Next=Temp2;
    }

}
void Display(PNODE Head)
{
    if(Head==NULL)
    {
        return;
    }
    while(Head!=NULL)
    {
        printf("|%d|->",Head->Data);
        Head=Head->Next;
    }
    printf("NULL");
}


int main()
{
    int iChoice=1, iCount=0,iPos=0,iNo=0;
    PNODE First=NULL;

    while(iChoice!=0)
    {
         printf("\n-------------------------------------------------------------------------------------------\n");
         printf("Enter:\n1.For insert first.\n2.For Insert last.\n3.For Display Singly linear linked list.\n4.For count members of Singly linear linked list.\n5.For insert at position.\n6.For Delete first.\n7.For delete Last.\n8.For Delete at position.\n0.For Exit\n");
         printf("-------------------------------------------------------------------------------------------\n");
         printf("Choose the option: \n");
         scanf("%d",&iChoice);
         printf("-------------------------------------------------------------------------------------------\n");

         switch(iChoice)
         {
            case 1:
                printf("Enter the element to add at first position.\n");
                scanf("%d",&iNo);
                InsertFirst(&First,iNo);
                break;
            case 2:
                printf("Enter the element to add at Last Position.\n");
                scanf("%d",&iNo);
                InsertLast(&First,iNo);
                break;
            case 3:
                printf("Elements of your linked list are.\n");
                Display(First);
                break;
            case 4:
                iCount=Count(First);
                printf("Number of elements in singly linear linked list are: %d\n",iCount);
                break;
            case 5:
                printf("Enter the element to add in singly linear linked list.\n");
                scanf("%d",&iNo);
                printf("Enter the position\n");
                scanf("%d",&iPos);
                InsertAtPos(&First,iNo,iPos);
                break;
            case 6:
                DeleteFirst(&First);
                break;
            case 7:
                DeleteLast(&First);
                break;
            case 8:
                printf("Enter the position to Delete element\n");
                scanf("%d",&iPos);
                DeleteAtPos(&First,iPos);
                break;
            case 0:
                break;
            default:
                printf("Wrong Choice.\n");
                break;
            
         }
    }
    printf("Thank You For Using Application.\n");
    return 0;
}