//Generic progtam to multiply two number

using namespace std;
#include<iostream>

template<class T>
T Mult(T No1,T No2)
{
    return No1*No2;
}

int main()
{
    int iNo1=0,iNo2=0,Ret=0;
    float fNo1=0.0,fNo2=0.0;
    double dNo1=0.0,dNo2=0.0;

    cout<<"Enter the First number\n";
    cin>>iNo1;
    cout<<"Enter the Second number\n";
    cin>>iNo2;

   
    Ret=Mult(iNo1,iNo2);

    cout<<"answer is "<<Ret;
    
    cout<<"\nEnter the First number\n";
    cin>>fNo1;
    cout<<"Enter the Second number\n";
    cin>>fNo2;

   
    Ret=Mult(fNo1,fNo2);

    cout<<"answer is "<<Ret;
    return 0;
}