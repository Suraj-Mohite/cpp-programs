//first occurance

using namespace std;
#include<iostream>

template<class T>
int locc(T*arr,int size,T no)
{
    int i=0;
    for(i=size-1;i>=0;i--)
    {
        if(arr[i]==no)
        {
            break;
        }
    }
    if(i==-1)
    {
        return -1;
    }
    else{
        return i;
    }
}
int main()
{
    int size=0,no=0;
    float ino=0.0;
    cout<<"Enter the size of array\n";
    cin>>size;
   
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }
    
    cout<<"Enter the element to find last occurance\n";
    cin>>no;
    cout<<"last occurance is "<<locc(arr,size,no);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"Enter the element to find last occurance\n";
    cin>>ino;
    cout<<"last occurance is "<<locc(brr,size,ino);


    return 0;
}