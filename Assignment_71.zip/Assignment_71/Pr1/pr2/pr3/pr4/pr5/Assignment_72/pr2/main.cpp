

using namespace std;
#include<iostream>

template<class T>
int freq(T*arr,int size,T no)
{
    int i=0,icnt=0;
    for(i=0;i<size;i++)
    {
        if(arr[i]==no)
        {
            icnt++;
        }
    }
    return icnt;
}
int main()
{
    int size=0,no=0;
    float ino=0.0;
    cout<<"Enter the size of array\n";
    cin>>size;
   
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }
    
    cout<<"Enter the element to find frequency\n";
    cin>>no;
    cout<<"frequency is "<<freq(arr,size,no);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"Enter the element to find frequency\n";
    cin>>ino;
    cout<<"frequency is "<<freq(brr,size,ino);


    return 0;
}