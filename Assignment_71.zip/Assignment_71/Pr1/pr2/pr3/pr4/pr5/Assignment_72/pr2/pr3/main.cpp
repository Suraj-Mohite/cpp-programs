//first occurance

using namespace std;
#include<iostream>

template<class T>
int focc(T*arr,int size,T no)
{
    int i=0;
    for(i=0;i<size;i++)
    {
        if(arr[i]==no)
        {
            break;
        }
    }
    if(i==size)
    {
        return -1;
    }
    else{
        return i;
    }
}
int main()
{
    int size=0,no=0;
    float ino=0.0;
    cout<<"Enter the size of array\n";
    cin>>size;
   
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }
    
    cout<<"Enter the element to find first occurance\n";
    cin>>no;
    cout<<"first occurance is "<<focc(arr,size,no);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"Enter the element to find first occurance\n";
    cin>>ino;
    cout<<"first occurance is "<<focc(brr,size,ino);


    return 0;
}