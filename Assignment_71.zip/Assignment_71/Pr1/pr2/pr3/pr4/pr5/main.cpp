//Accept N number and return largest elements

using namespace std;
#include<iostream>

template<class T>
T Min(T*arr,int size)
{
    T min=arr[0];
    int i=0;
    for(i=1;i<size;i++)
    {
        if(arr[i]<min)
        {
            min=arr[i];
        }
    }
    return min;
}
int main()
{
    int size=0;
    cout<<"Enter the size of array\n";
    cin>>size;
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"minimum element is "<<Min(arr,size);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"minimum element is "<<Min(brr,size);


    return 0;
}