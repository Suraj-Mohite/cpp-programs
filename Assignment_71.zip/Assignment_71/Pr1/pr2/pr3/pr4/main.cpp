//Accept N number and return largest elements

using namespace std;
#include<iostream>

template<class T>
T large(T*arr,int size)
{
    T max=arr[0];
    int i=0;
    for(i=1;i<size;i++)
    {
        if(arr[i]>max)
        {
            max=arr[i];
        }
    }
    return max;
}
int main()
{
    int size=0;
    cout<<"Enter the size of array\n";
    cin>>size;
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Maximum element is "<<large(arr,size);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"Maximum element is "<<large(brr,size);


    return 0;
}