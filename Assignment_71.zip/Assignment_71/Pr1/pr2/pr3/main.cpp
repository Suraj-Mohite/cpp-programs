//Accept N number and return addition of elements

using namespace std;
#include<iostream>

template<class T>
T Add(T*arr,int size)
{
    T sum=0;
    int i=0;
    for(i=0;i<size;i++)
    {
        sum=sum+arr[i];
    }
    return sum;
}
int main()
{
    int size=0;
    cout<<"Enter the size of array\n";
    cin>>size;
    int*arr=new int[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Addition is "<<Add(arr,size);

    cout<<"\nEnter the size of array\n";
    cin>>size;
    float*brr=new float[size];

    cout<<"Enter the elements\n";
    for(int i=0;i<size;i++)
    {
        cin>>brr[i];
    }

    cout<<"Addition is "<<Add(brr,size);


    return 0;
}