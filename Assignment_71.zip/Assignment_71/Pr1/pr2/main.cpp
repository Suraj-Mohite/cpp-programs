//largest number from three numbers
using namespace std;
#include<iostream>

template<class T>
T Max(T No1,T No2,T No3)
{
    if((No1>=No2)&&(No1>=No3))
    {
        return No1;
    }
    else if((No2>=No1)&&(No2>=No3))
    {
        return No2;
    }
    else
    {
        return No3;
    }
}

int main()
{
    int iNo1=0,iNo2=0,iNo3=0;
    float fNo1=0,fNo2=0,fNo3=0;

    cout<<"Enter the first number\n";
    cin>>iNo1;
    cout<<"Enter the second number\n";
    cin>>iNo2;
    cout<<"Enter the third number\n";
    cin>>iNo3;

    cout<<"Max is"<<Max(iNo1,iNo2,iNo3);

    cout<<"\nEnter the first number\n";
    cin>>fNo1;
    cout<<"Enter the second number\n";
    cin>>fNo2;
    cout<<"Enter the third number\n";
    cin>>fNo3;

    cout<<"Max is"<<Max(fNo1,fNo2,fNo3);
    return 0;
}