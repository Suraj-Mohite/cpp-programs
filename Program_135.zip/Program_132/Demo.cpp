#include<iostream>
using namespace std;

class Array
{
    public:
    int*Arr;
    int size;

    Array(int length=10)
    {
        cout<<"Inside constructor\n";
        Arr=new int[length];
        size=length;
    }

    ~Array(){

        delete[]Arr;
    }
    void Accept()
    {
        cout<<"Enter the element\n";
        for(int i=0;i<size;i++){
            cin>>Arr[i];
        }
    }
    void Display()
    {
        cout<<"Elements of array\n";
        for(int i=0;i<size;i++){
            cout<<Arr[i]<<"\t";
        }
        cout<<"\n";
    }

};

int main()
{
    cout<<sizeof(obj1);
    /*int iNo=0;
    cout<<"Enter the number of ewlement\n";
    cin>>iNo;*/
    Array*obj1=new Array(); //Dynamic object creation 
    obj1->Accept();
    obj1->Display();
    
    delete obj1;
    return 0;
}