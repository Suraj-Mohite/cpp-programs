using namespace std;
#include<iostream>

template <class T>
T max(T ino1,T ino2,T ino3)
{
    if(ino1>=ino2&&ino1>=ino3)
    {
        return ino1;
    }
    if(ino2>=ino1&&ino2>=ino3)
    {
        return ino2;
    }
    else{
        return ino3;
    }
}
int main()
{
    float value1,value2,value3,fRet=0.0;

    cout<<"Enter the first number\n";
    cin>>value1;
    cout<<"Enter the second number\n";
    cin>>value2;
    cout<<"Enter the third number\n";
    cin>>value3;
    fRet=max(value1,value2,value3);
    cout<<"max is \n"<<fRet;

    int ivalue1,ivalue2,ivalue3,iRet=0;

    cout<<"\nEnter the first number\n";
    cin>>ivalue1;

    cout<<"Enter the second number\n";
    cin>>ivalue2;

    cout<<"Enter the third number\n";
    cin>>ivalue3;

    iRet=max(ivalue1,ivalue2,ivalue3);
    cout<<"max is "<<iRet;

    char cvalue1,cvalue2,cvalue3,cRet=0;

    cout<<"\nEnter the first number\n";
    cin>>cvalue1;

    cout<<"Enter the second number\n";
    cin>>cvalue2;

    cout<<"Enter the third number\n";
    cin>>cvalue3;

    cRet=max(cvalue1,cvalue2,cvalue3);
    cout<<"max is "<<cRet;
    
    double dvalue1,dvalue2,dvalue3,dRet=0;

    cout<<"\nEnter the first number\n";
    cin>>dvalue1;

    cout<<"Enter the second number\n";
    cin>>dvalue2;

    cout<<"Enter the third number\n";
    cin>>dvalue3;

    dRet=max(dvalue1,dvalue2,dvalue3);
    cout<<"max is "<<dRet;
    
    return 0;
}