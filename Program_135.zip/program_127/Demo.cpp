using namespace std;
#include<iostream>
/*int main()
{
    cout<<"Hello Suraj";
    return 0;
}*/

int max(int ino1,int ino2,int ino3)
{
    if(ino1>=ino2&&ino1>=ino3)
    {
        return ino1;
    }
    if(ino2>=ino1&&ino2>=ino3)
    {
        return ino2;
    }
    else{
        return ino3;
    }
}
int main()
{
    int value1,value2,value3,iRet=0;

    cout<<"Enter the first number\n";
    cin>>value1;
    cout<<"Enter the second number\n";
    cin>>value2;
    cout<<"Enter the third number\n";
    cin>>value3;
    iRet=max(value1,value2,value3);
    cout<<"max is "<<iRet;
    return 0;
}