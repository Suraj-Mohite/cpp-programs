#include<iostream>
using namespace std;

typedef int BOOL;
#define TRUE 1
#define FALSE 0

class Array
{
    public:
    int*Arr;
    int size;

    Array(int length=10)
    {
        cout<<"Inside constructor\n";
        Arr=new int[length];
        size=length;
    }

    ~Array(){

        delete[]Arr;
    }
    
    void Accept()
    {
        cout<<"Enter the element\n";
        for(int i=0;i<size;i++){
            cin>>Arr[i];
        }
    }
    void Display()
    {
        cout<<"Elements of array\n";
        for(int i=0;i<size;i++){
            cout<<Arr[i]<<"\t";
        }
        cout<<"\n";
    }

};

class Searching:public Array
{
    public:
    Searching(int no=10):Array(no){}
    BOOL LinearSearch(int no)
    {
        int i=0;
        for(i=0;i<size;i++){
            if(Arr[i]==no)
            {
                break;
            }
        }
        if(i==size){
            return FALSE;
            }
        else{
            return TRUE;
            }
    }
};
int main()
{
    int iNo=0,iValue=0;
    cout<<"Enter number of elements\n";
    cin>>iNo;   
    Searching*obj1=new Searching(iNo); //Dynamic object creation 
    obj1->Accept();
    obj1->Display();

    cout<<"Enter element to search\n";
    cin>>iValue; 

    BOOL bret=FALSE;
    bret=obj1->LinearSearch(iValue);
    if(bret==TRUE)
    {
        cout<<"present";
    } 
    else{
        cout<<"not";
    }
    
    delete obj1;
    return 0;
}