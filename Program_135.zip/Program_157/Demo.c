#include<stdio.h>
#include<stdlib.h>


int FormIp(int no1,int no2,int no3,int no4)
{
    int iRet=0;

    no1=no1&0x000000ff;
    no2=no2&0x000000ff;
    no3=no3&0x000000ff;
    no4=no4&0x000000ff;

    
    return 0;
}
int main()
{
    int a,b,c,d;
    int iRet=0;
    printf("Enter Ip Address\n");    
    printf("Enter 1st no.");    
    scanf("%d",&a);
    printf("Enter 2 no.");    
    scanf("%d",&b);
    printf("Enter 3 no.");    
    scanf("%d",&c);
    printf("Enter 4 no.");    
    scanf("%d",&d);

    iRet=FormIp(a,b,c,d);
    scanf("%d",&iRet);
    return 0;

}